"""
实验1: ARIMA(1,1,1)模型

传统统计模型基准
"""

import sys
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')  # 忽略所有警告
import os
os.environ['PYTHONWARNINGS'] = 'ignore'  # 忽略所有警告

# 导入通用配置
from common_config import *
from common_utils import *

# ARIMA相关
from statsmodels.tsa.arima.model import ARIMA
from itertools import product

def select_arima_order(train_data, p_range, d_range, q_range):
    """
    使用AIC选择最优ARIMA阶数
    """
    best_aic = float('inf')
    best_order = None
    
    for p, d, q in product(p_range, d_range, q_range):
        try:
            model = ARIMA(train_data, order=(p, d, q))
            results = model.fit()
            if results.aic < best_aic:
                best_aic = results.aic
                best_order = (p, d, q)
        except:
            continue
    
    return best_order if best_order else (1, 1, 1)

def train_and_predict_arima(stock_key):
    """
    训练ARIMA并预测单只股票
    """
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    # 加载数据
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    # 分割数据
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    # 使用固定的ARIMA(1,1,1) - 金融序列标准基准模型
    order = (1, 1, 1)
    print(f"使用ARIMA{order}模型")
    
    # 训练模型
    print("训练ARIMA模型...")
    model = ARIMA(train_df['close'].values, order=order)
    results = model.fit()
    
    # 预测
    print("进行预测...")
    predictions = []
    history = list(train_df['close'].values)
    
    for t in range(len(test_df)):
        model_temp = ARIMA(history, order=order)
        model_fit = model_temp.fit()
        yhat = model_fit.forecast()[0]
        predictions.append(yhat)
        history.append(test_df['close'].values[t])
    
    predictions = np.array(predictions)
    
    # 计算指标
    y_true = test_df['close'].values
    metrics = calculate_metrics(y_true, predictions)
    print_metrics(metrics, "  ")
    
    # 保存结果
    output_prefix = get_output_prefix('exp01_ARIMA', stock_key)
    
    # 保存预测
    save_predictions(
        test_df['date'],
        y_true,
        predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    # 保存指标
    save_metrics(
        metrics,
        'exp01_ARIMA',
        stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    # 绘图
    plot_predictions(
        test_df['date'],
        y_true,
        predictions,
        f'ARIMA - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验1: ARIMA(1,1,1)模型")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_arima(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验1: ARIMA(1,1,1) 完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
