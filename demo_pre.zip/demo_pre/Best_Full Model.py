"""
Best Full Model: CEEMDAN-ReliefF-AttLSTM-PSO（最优参数版本）

使用寻优_Full_Model_最优参数.py找到的最佳超参数配置：
- max_lag: 11
- n_features: 5
- lstm_units: 256
- dense_units: 64
- lr: 0.003665035
- batch_size: 16
- dropout: 0.13344916
- ceemdan_trials: 86

运行12个数据集，输出对比表格和AAPL可视化图像
"""

import sys
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import copy
import warnings
warnings.filterwarnings('ignore')

import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from skrebate import ReliefF

# 修复PyEMD导入
from PyEMD.EMD import EMD
import PyEMD
PyEMD.EMD = EMD
from PyEMD.CEEMDAN import CEEMDAN

import os
from pathlib import Path

# ============================================================================
# 🌟 最优参数配置（来自参数优化结果）
# ============================================================================

# 数据路径
DATA_FILE = r'C:\Users\FXY\PyCharmMiscProject\Thesis\11.29Finally Prediction\描述性统计分析\result\final_data.xlsx'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.2Prediction\参数优化\result_best_model'

# 创建输出目录
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, 'predictions'), exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, 'metrics'), exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, 'figures'), exist_ok=True)

# 股票列表（12只股票）
STOCK_DATASETS = {
    # NDX数据集（4只）
    'NDX_AAPL': ('NDX', 'AAPL'),
    'NDX_MSFT': ('NDX', 'MSFT'),
    'NDX_GOOG': ('NDX', 'GOOG'),
    'NDX_KHC': ('NDX', 'KHC'),
    
    # NJIA数据集（4只）
    'NJIA_CRM': ('NJIA', 'CRM'),
    'NJIA_HD': ('NJIA', 'HD'),
    'NJIA_MCD': ('NJIA', 'MCD'),
    'NJIA_V': ('NJIA', 'V'),
    
    # SP数据集（4只）
    'SP_MSFT': ('SP', 'MSFT'),
    'SP_AMD': ('SP', 'AMD'),
    'SP_JPM': ('SP', 'JPM'),
    'SP_BAC': ('SP', 'BAC')
}

ALL_STOCK_KEYS = list(STOCK_DATASETS.keys())

# 🌟 最优超参数（来自优化结果）
MAX_LAG = 11
N_FEATURES_TO_SELECT = 5
LSTM_UNITS = 256
DENSE_UNITS = 64
DROPOUT = 0.13344916
LR = 0.003665035
BATCH_SIZE = 16
CEEMDAN_TRIALS = 86

# 训练参数
EPOCHS = 200
PATIENCE = 50  # 用户要求
TRAIN_RATIO = 0.9

# PSO参数
PSO_POP_SIZE = 50
PSO_MAX_ITER = 100

# 设备
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

print("="*80)
print("Best Full Model - 最优参数配置")
print("="*80)
print(f"MAX_LAG: {MAX_LAG}")
print(f"N_FEATURES: {N_FEATURES_TO_SELECT}")
print(f"LSTM_UNITS: {LSTM_UNITS}")
print(f"DENSE_UNITS: {DENSE_UNITS}")
print(f"LR: {LR:.6f}")
print(f"BATCH_SIZE: {BATCH_SIZE}")
print(f"DROPOUT: {DROPOUT:.6f}")
print(f"CEEMDAN_TRIALS: {CEEMDAN_TRIALS}")
print(f"PATIENCE: {PATIENCE}")
print(f"DEVICE: {DEVICE}")
print("="*80)

# ============================================================================
# 数据加载
# ============================================================================

def load_stock_data(data_path, sheet_name, stock_name):
    """加载单只股票数据"""
    df = pd.read_excel(data_path, sheet_name=sheet_name)
    df['date'] = pd.to_datetime(df['date'])
    
    if stock_name not in df.columns:
        raise ValueError(f"股票 {stock_name} 不存在于 {sheet_name} 数据集中")
    
    df = df[['date', stock_name]].copy()
    df.rename(columns={stock_name: 'close'}, inplace=True)
    df = df.dropna().sort_values('date').reset_index(drop=True)
    
    return df

def split_train_test(df, train_ratio=0.9):
    """分割训练集和测试集"""
    split_idx = int(len(df) * train_ratio)
    train_df = df.iloc[:split_idx].reset_index(drop=True)
    test_df = df.iloc[split_idx:].reset_index(drop=True)
    return train_df, test_df

# ============================================================================
# PyTorch数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# AttLSTM模型定义
# ============================================================================

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Linear(hidden_size, 1)
    
    def forward(self, lstm_output):
        attention_weights = torch.softmax(self.attention(lstm_output), dim=1)
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)
        return context_vector

class AttLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=256, dense_units=64, dropout=0.13):
        super(AttLSTM, self).__init__()
        
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        
        self.attention = AttentionLayer(lstm_units)
        
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        
        x = self.attention(x)
        
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        
        return x.squeeze()

# ============================================================================
# 工具函数
# ============================================================================

def normalize_data(train_data, test_data):
    """标准化数据"""
    scaler = StandardScaler()
    train_scaled = scaler.fit_transform(train_data.reshape(-1, 1)).flatten()
    test_scaled = scaler.transform(test_data.reshape(-1, 1)).flatten()
    return train_scaled, test_scaled, scaler

def create_lagged_features(data, lags):
    """创建滞后特征"""
    max_lag = max(lags)
    n = len(data)
    
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    
    return X, y

def relieff_feature_selection(data, max_lag=11, n_features=5):
    """使用ReliefF选择最优滞后特征"""
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(data, all_lags)
    
    relieff = ReliefF(n_features_to_select=n_features, n_neighbors=10)
    relieff.fit(X, y)
    
    selected_indices = relieff.top_features_[:n_features]
    selected_lags = [all_lags[i] for i in selected_indices]
    selected_lags.sort()
    
    return selected_lags

def clip_weights(weights, w_min=1e-6, w_max=1.5):
    """限制权重范围"""
    return np.clip(weights, w_min, w_max)

def calculate_metrics(y_true, y_pred):
    """计算所有评估指标"""
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()
    
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-8))) * 100
    
    if len(y_true) > 1:
        true_direction = np.sign(np.diff(y_true))
        pred_direction = np.sign(np.diff(y_pred))
        da = np.mean(true_direction == pred_direction) * 100
    else:
        da = 0.0
    
    numerator = np.sqrt(np.mean((y_pred - y_true) ** 2))
    denominator = np.sqrt(np.mean(y_true ** 2)) + np.sqrt(np.mean(y_pred ** 2))
    tic = numerator / (denominator + 1e-8)
    
    return {
        'MAE': mae,
        'RMSE': rmse,
        'R^2': r2,
        'MAPE': mape,
        'DA': da,
        'TIC': tic
    }

# ============================================================================
# 训练单个IMF
# ============================================================================

def train_single_imf(imf_train, imf_test, selected_lags, imf_idx, n_imfs, stock_key):
    """训练单个IMF的AttLSTM模型，输出训练过程"""
    
    print(f"  训练 IMF {imf_idx+1}/{n_imfs}... ", end='', flush=True)
    
    # 标准化
    train_scaled, test_scaled, scaler = normalize_data(imf_train, imf_test)
    
    # 创建滞后特征
    imf_scaled = np.concatenate([train_scaled, test_scaled])
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割
    max_lag = max(selected_lags)
    train_size = len(imf_train)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 模型
    model = AttLSTM(
        input_dim=len(selected_lags),
        lstm_units=LSTM_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    # 🌟 训练循环（输出进度）
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        # 🌟 每10个epoch输出一次
        if (epoch + 1) % 10 == 0:
            print(f"\n    Epoch {epoch+1}/{EPOCHS}: Train Loss={train_loss:.6f}, Val Loss={val_loss:.6f}, Patience={patience_counter}/{PATIENCE}", flush=True)
        
        if patience_counter >= PATIENCE:
            print(f"\n    早停于 Epoch {epoch+1}", flush=True)
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    # 预测
    model.eval()
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    # 反标准化
    test_pred = scaler.inverse_transform(
        np.array(test_pred_scaled).reshape(-1, 1)
    ).flatten()
    
    print(f"完成！", flush=True)
    
    return test_pred

# ============================================================================
# PSO优化权重
# ============================================================================

def pso_optimize_weights(imf_predictions, true_values):
    """使用PSO优化集成权重"""
    n_imfs = len(imf_predictions)
    
    def objective(weights):
        weights = clip_weights(weights)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        mae = np.mean(np.abs(true_values - pred))
        return mae
    
    # 初始化粒子
    particles = []
    velocities = []
    for _ in range(PSO_POP_SIZE):
        particle = np.random.uniform(0.3, 1.5, n_imfs)
        particles.append(clip_weights(particle))
        velocities.append(np.random.uniform(-0.1, 0.1, n_imfs))
    
    particles = np.array(particles)
    velocities = np.array(velocities)
    
    pbest = particles.copy()
    pbest_scores = np.array([objective(p) for p in particles])
    
    gbest_idx = np.argmin(pbest_scores)
    gbest = pbest[gbest_idx].copy()
    gbest_score = pbest_scores[gbest_idx]
    
    w = 0.7
    c1 = 1.5
    c2 = 1.5
    
    for iteration in range(PSO_MAX_ITER):
        for i in range(PSO_POP_SIZE):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (pbest[i] - particles[i]) +
                           c2 * r2 * (gbest - particles[i]))
            
            particles[i] = particles[i] + velocities[i]
            particles[i] = clip_weights(particles[i])
            
            score = objective(particles[i])
            
            if score < pbest_scores[i]:
                pbest[i] = particles[i].copy()
                pbest_scores[i] = score
                
                if score < gbest_score:
                    gbest = particles[i].copy()
                    gbest_score = score
    
    optimal_weights = clip_weights(gbest)
    return optimal_weights

# ============================================================================
# 主训练函数
# ============================================================================

def train_and_predict_best_model(stock_key):
    """训练最优模型并预测单只股票"""
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    # 加载数据
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    df = load_stock_data(DATA_FILE, dataset_name, stock_name)
    
    # 分割数据
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    prices = df['close'].values
    train_size = len(train_df)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    # CEEMDAN分解
    print(f"CEEMDAN分解中 (trials={CEEMDAN_TRIALS})...")
    ceemdan = CEEMDAN(trials=CEEMDAN_TRIALS)
    imfs = ceemdan(prices)
    n_imfs = len(imfs)
    print(f"分解完成: {n_imfs}个IMF分量")
    
    # 训练各IMF
    print(f"\n训练各IMF (max_lag={MAX_LAG}, n_features={N_FEATURES_TO_SELECT})...")
    imf_test_predictions = []
    
    for i in range(n_imfs):
        # 切分IMF
        imf_train = imfs[i][:train_size]
        imf_test = imfs[i][train_size:]
        
        # ReliefF特征选择
        selected_lags = relieff_feature_selection(
            imf_train, MAX_LAG, N_FEATURES_TO_SELECT
        )
        print(f"\n  IMF {i+1}/{n_imfs} - 选择的滞后项: {selected_lags}")
        
        # 训练并预测
        test_pred = train_single_imf(imf_train, imf_test, selected_lags, i, n_imfs, stock_key)
        imf_test_predictions.append(test_pred)
    
    # 对齐长度
    min_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions = [p[-min_len:] for p in imf_test_predictions]
    test_true = test_df['close'].values[-min_len:]
    test_dates = test_df['date'].values[-min_len:]
    
    # PSO优化权重
    print(f"\nPSO优化权重...")
    optimal_weights = pso_optimize_weights(imf_test_predictions, test_true)
    print(f"最优权重: {optimal_weights}")
    print(f"权重和: {np.sum(optimal_weights):.4f}")
    
    # 集成预测
    predictions = sum(w * p for w, p in zip(optimal_weights, imf_test_predictions))
    
    # 计算指标
    metrics = calculate_metrics(test_true, predictions)
    print(f"\n评估指标:")
    print(f"  MAE:  {metrics['MAE']:.4f}")
    print(f"  RMSE: {metrics['RMSE']:.4f}")
    print(f"  R^2:  {metrics['R^2']:.4f}")
    print(f"  MAPE: {metrics['MAPE']:.2f}%")
    print(f"  DA:   {metrics['DA']:.2f}%")
    print(f"  TIC:  {metrics['TIC']:.4f}")
    
    # 保存结果
    output_prefix = f'BestModel_{stock_key}'
    
    # 保存预测值
    pred_df = pd.DataFrame({
        'date': test_dates,
        'true': test_true,
        'pred': predictions
    })
    pred_df.to_csv(os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv'), index=False)
    
    # 保存指标
    metrics_df = pd.DataFrame({
        'model': ['BestFullModel'],
        'stock': [stock_key],
        **{k: [v] for k, v in metrics.items()}
    })
    
    metrics_file = os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    if os.path.exists(metrics_file):
        metrics_df.to_csv(metrics_file, mode='a', header=False, index=False, encoding='utf-8-sig')
    else:
        metrics_df.to_csv(metrics_file, index=False, encoding='utf-8-sig')
    
    print(f"\n{stock_key} 完成!")
    
    return metrics, test_dates, test_true, predictions

# ============================================================================
# 可视化AAPL
# ============================================================================

def plot_aapl_results(test_dates, test_true, predictions, metrics):
    """绘制AAPL的可视化拟合图像（中文编码）"""
    
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))
    
    # 上图：预测vs真实值
    ax1 = axes[0]
    ax1.plot(test_dates, test_true, label='真实值', linewidth=2, color='blue', alpha=0.7)
    ax1.plot(test_dates, predictions, label='预测值', linewidth=2, color='red', alpha=0.7, linestyle='--')
    ax1.set_xlabel('日期', fontsize=12)
    ax1.set_ylabel('收盘价', fontsize=12)
    ax1.set_title('AAPL股票预测结果 - Best Full Model（最优参数）', fontsize=14, fontweight='bold')
    ax1.legend(loc='best', fontsize=11)
    ax1.grid(True, alpha=0.3)
    
    # 添加指标文本
    metrics_text = f"MAE={metrics['MAE']:.2f}, RMSE={metrics['RMSE']:.2f}, R²={metrics['R^2']:.4f}\n"
    metrics_text += f"MAPE={metrics['MAPE']:.2f}%, DA={metrics['DA']:.2f}%, TIC={metrics['TIC']:.4f}"
    ax1.text(0.02, 0.98, metrics_text, transform=ax1.transAxes, 
             fontsize=10, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # 下图：误差分布
    ax2 = axes[1]
    errors = predictions - test_true
    ax2.plot(test_dates, errors, label='预测误差', linewidth=1.5, color='green', alpha=0.7)
    ax2.axhline(y=0, color='black', linestyle='-', linewidth=1, alpha=0.5)
    ax2.fill_between(test_dates, errors, 0, alpha=0.3, color='green')
    ax2.set_xlabel('日期', fontsize=12)
    ax2.set_ylabel('误差（预测值 - 真实值）', fontsize=12)
    ax2.set_title('预测误差分布', fontsize=13, fontweight='bold')
    ax2.legend(loc='best', fontsize=11)
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 保存图像
    save_path = os.path.join(OUTPUT_DIR, 'figures', 'AAPL_BestModel_Visualization.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"\nAAPL可视化图像已保存: {save_path}")
    plt.close()

# ============================================================================
# 生成对比表格
# ============================================================================

def generate_comparison_tables():
    """生成12个数据集6个评估指标的对比表格"""
    
    print("\n" + "="*80)
    print("生成对比表格")
    print("="*80)
    
    metrics_file = os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    
    if not os.path.exists(metrics_file):
        print(f"错误: 指标文件不存在 - {metrics_file}")
        return
    
    df = pd.read_csv(metrics_file, encoding='utf-8-sig')
    
    print(f"加载指标数据: {len(df)} 条记录")
    
    # 转置表格：行=股票，列=指标
    result_df = df.set_index('stock')[['MAE', 'RMSE', 'R^2', 'MAPE', 'DA', 'TIC']]
    
    # 添加统计行
    result_df.loc['Mean'] = result_df.mean()
    result_df.loc['Std'] = result_df.std()
    result_df.loc['Min'] = result_df.min()
    result_df.loc['Max'] = result_df.max()
    
    # 保存CSV
    output_path = os.path.join(OUTPUT_DIR, 'comparison_table_all_stocks.csv')
    result_df.to_csv(output_path, encoding='utf-8-sig')
    print(f"✓ 已生成对比表格（CSV）: {output_path}")
    
    # 保存Excel
    output_path_excel = os.path.join(OUTPUT_DIR, 'comparison_table_all_stocks.xlsx')
    with pd.ExcelWriter(output_path_excel, engine='openpyxl') as writer:
        result_df.to_excel(writer, sheet_name='All Metrics')
        worksheet = writer.sheets['All Metrics']
        
        # 设置列宽
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 20)
            worksheet.column_dimensions[column].width = adjusted_width
    
    print(f"✓ 已生成对比表格（Excel）: {output_path_excel}")
    
    # 打印表格预览
    print("\n表格预览:")
    print(result_df.to_string())
    
    print("\n" + "="*80)

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("Best Full Model - 使用最优参数运行12个数据集")
    print("="*80)
    
    all_results = {}
    aapl_data = None
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics, test_dates, test_true, predictions = train_and_predict_best_model(stock_key)
            all_results[stock_key] = metrics
            
            # 保存AAPL数据用于可视化
            if stock_key == 'NDX_AAPL':
                aapl_data = (test_dates, test_true, predictions, metrics)
                
        except Exception as e:
            print(f"\n错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"所有股票训练完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")
    
    # 生成对比表格
    generate_comparison_tables()
    
    # 绘制AAPL可视化
    if aapl_data is not None:
        print("\n" + "="*80)
        print("生成AAPL可视化图像")
        print("="*80)
        plot_aapl_results(*aapl_data)
    
    print("\n" + "="*80)
    print("✅ Best Full Model 运行完成！")
    print("="*80)
    print(f"结果保存在: {OUTPUT_DIR}")
    print("  - predictions/ : 预测结果CSV")
    print("  - metrics/ : 评估指标CSV")
    print("  - figures/ : AAPL可视化图像")
    print("  - comparison_table_all_stocks.xlsx : 对比表格")
    print("="*80)

if __name__ == '__main__':
    main()
