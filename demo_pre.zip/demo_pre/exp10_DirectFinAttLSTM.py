"""
实验10: 直接预测 - 金融注意力LSTM (Direct Financial Attention LSTM)

核心创新：真正的金融注意力机制
==========================================

1. ✅ 不使用CEEMDAN分解，直接预测原始价格序列
2. ✅ 金融特性建模：
   - 时间衰减注意力（近期更重要）
   - 波动性感知门控（高波动期降权）
   - 趋势感知机制（上升/下降趋势识别）
   - 价格水平感知（相对高低位调整）
3. ✅ 丰富的金融特征：
   - 价格本身
   - 收益率（Returns）
   - 移动平均（MA）
   - 波动率（Volatility）
   - 动量（Momentum）
   - RSI相对强弱指标
4. ✅ 端到端训练，无数据泄漏

实验目标：验证金融注意力在直接预测中的有效性
对比基准：标准LSTM、标准AttLSTM
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import copy
import warnings
warnings.filterwarnings('ignore')

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler

# 评估指标
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ============================================================================
# 配置参数
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\portfolio\dataset\SP_original\SP_factor.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\11.28prediction\comparison\result'

DATA_START = '2015-07-01'
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

# ✅ 直接预测参数
LOOKBACK_WINDOW = 20  # 用过去20天预测未来1天
PREDICTION_HORIZON = 1  # 预测未来1天

# ✅ 金融特征参数
USE_PRICE = True
USE_RETURNS = True
USE_MA = True
USE_VOLATILITY = True
USE_MOMENTUM = True
USE_RSI = True

MA_WINDOWS = [5, 10, 20]  # 多个MA周期
VOLATILITY_WINDOW = 10
MOMENTUM_WINDOW = 5
RSI_WINDOW = 14

# ✅ 模型参数
LSTM_UNITS = 128
DENSE_UNITS = 64
DROPOUT = 0.3
LR = 0.0001  # 进一步降低学习率，避免梯度爆炸
BATCH_SIZE = 64  # 增大批量，提高训练稳定性
EPOCHS = 300  # 增加训练轮次
PATIENCE = 30  # 增加耐心
GRAD_CLIP = 1.0  # 梯度裁剪阈值

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y, X_raw=None):
        """
        Args:
            X: 归一化后的特征 (n_samples, lookback, n_features)
            y: 归一化后的目标 (n_samples,)
            X_raw: 原始价格序列 (n_samples, lookback) - 用于计算金融特征
        """
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
        self.X_raw = torch.FloatTensor(X_raw) if X_raw is not None else None
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        if self.X_raw is not None:
            return self.X[idx], self.y[idx], self.X_raw[idx]
        else:
            return self.X[idx], self.y[idx]

# ============================================================================
# 金融特征计算
# ============================================================================

def calculate_returns(prices, periods=1):
    """计算收益率"""
    returns = np.diff(prices, n=periods, prepend=prices[0]) / (prices + 1e-8)
    # 处理可能的inf和nan
    returns = np.nan_to_num(returns, nan=0.0, posinf=0.1, neginf=-0.1)
    return returns

def calculate_ma(prices, window):
    """计算移动平均"""
    return pd.Series(prices).rolling(window=window, min_periods=1).mean().values

def calculate_volatility(prices, window):
    """计算滚动波动率（标准差）"""
    returns = calculate_returns(prices, 1)
    return pd.Series(returns).rolling(window=window, min_periods=1).std().values

def calculate_momentum(prices, window):
    """计算动量（当前价格 - N天前价格）"""
    momentum = np.zeros_like(prices)
    for i in range(len(prices)):
        if i >= window:
            momentum[i] = prices[i] - prices[i - window]
        else:
            momentum[i] = 0
    return momentum

def calculate_rsi(prices, window=14):
    """计算RSI相对强弱指标"""
    deltas = np.diff(prices, prepend=prices[0])
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    
    avg_gains = pd.Series(gains).rolling(window=window, min_periods=1).mean().values
    avg_losses = pd.Series(losses).rolling(window=window, min_periods=1).mean().values
    
    rs = avg_gains / (avg_losses + 1e-8)
    rsi = 100 - (100 / (1 + rs))
    # 处理可能的nan
    rsi = np.nan_to_num(rsi, nan=50.0)
    return rsi

def create_financial_features(prices):
    """
    创建丰富的金融特征
    
    Args:
        prices: 原始价格序列
    
    Returns:
        features: (n_samples, n_features) 特征矩阵
    """
    features = []
    
    # 1. 价格本身（归一化）
    if USE_PRICE:
        features.append(prices.reshape(-1, 1))
    
    # 2. 收益率
    if USE_RETURNS:
        returns = calculate_returns(prices, 1)
        features.append(returns.reshape(-1, 1))
    
    # 3. 移动平均（多周期）
    if USE_MA:
        for window in MA_WINDOWS:
            ma = calculate_ma(prices, window)
            # 价格相对MA的偏离度
            ma_diff = (prices - ma) / (ma + 1e-8)
            # 处理可能的nan和inf
            ma_diff = np.nan_to_num(ma_diff, nan=0.0, posinf=1.0, neginf=-1.0)
            features.append(ma_diff.reshape(-1, 1))
    
    # 4. 波动率
    if USE_VOLATILITY:
        volatility = calculate_volatility(prices, VOLATILITY_WINDOW)
        features.append(volatility.reshape(-1, 1))
    
    # 5. 动量
    if USE_MOMENTUM:
        momentum = calculate_momentum(prices, MOMENTUM_WINDOW)
        features.append(momentum.reshape(-1, 1))
    
    # 6. RSI
    if USE_RSI:
        rsi = calculate_rsi(prices, RSI_WINDOW)
        # 归一化到[-1, 1]
        rsi_norm = (rsi - 50) / 50
        # 裁剪到合理范围
        rsi_norm = np.clip(rsi_norm, -1.0, 1.0)
        features.append(rsi_norm.reshape(-1, 1))
    
    # 拼接所有特征
    features = np.hstack(features)
    
    # 最终检查：替换所有nan和inf
    features = np.nan_to_num(features, nan=0.0, posinf=1.0, neginf=-1.0)
    
    return features

# ============================================================================
# 模型定义：金融注意力LSTM
# ============================================================================

class FinancialAttentionLayer(nn.Module):
    """
    金融注意力层
    
    核心思想：根据金融时间序列的特性动态调整注意力权重
    
    四大机制：
    1. 时间衰减：近期时间步权重更大
    2. 波动性感知：高波动期降低权重（噪声大）
    3. 趋势感知：识别上升/下降趋势
    4. 价格水平感知：相对高低位调整权重
    """
    def __init__(self, hidden_size):
        super(FinancialAttentionLayer, self).__init__()
        self.hidden_size = hidden_size
        
        # 基础内容注意力
        self.content_attention = nn.Linear(hidden_size, 1)
        
        # 金融特征注意力（5维 -> 1维）
        # [时间位置, 收益率, 波动率, 趋势, 价格水平]
        self.financial_attention = nn.Linear(5, 1)
        
        # 可学习的融合权重
        self.alpha = nn.Parameter(torch.tensor(0.5))  # 内容权重
        self.beta = nn.Parameter(torch.tensor(0.5))   # 金融特征权重
    
    def compute_financial_features(self, price_sequence):
        """
        计算金融注意力特征
        
        Args:
            price_sequence: (batch_size, seq_len) 原始价格序列
        
        Returns:
            financial_features: (batch_size, seq_len, 5) 金融特征
        """
        batch_size, seq_len = price_sequence.shape
        device = price_sequence.device
        
        # 归一化到[0, 1]（为了特征计算稳定）
        price_min = price_sequence.min(dim=1, keepdim=True)[0]
        price_max = price_sequence.max(dim=1, keepdim=True)[0]
        price_norm = (price_sequence - price_min) / (price_max - price_min + 1e-8)
        
        financial_feats = []
        
        for t in range(seq_len):
            # 特征1：时间位置（归一化）
            # 最近的是1.0，最远的是0.0
            time_position = torch.tensor(t / (seq_len - 1), device=device).expand(batch_size)
            
            # 特征2：局部收益率
            if t > 0:
                local_return = (price_sequence[:, t] - price_sequence[:, t-1]) / (price_sequence[:, t-1] + 1e-8)
            else:
                local_return = torch.zeros(batch_size, device=device)
            
            # 特征3：局部波动率（过去3步的标准差）
            if t >= 2:
                window = price_sequence[:, max(0, t-2):t+1]
                local_volatility = torch.std(window, dim=1)
            else:
                local_volatility = torch.zeros(batch_size, device=device)
            
            # 归一化波动率（避免过大）
            local_volatility = torch.tanh(local_volatility)
            
            # 特征4：趋势指示（过去5步的线性趋势）
            if t >= 4:
                window = price_norm[:, max(0, t-4):t+1]
                # 简单趋势：最后一个 - 第一个
                trend = window[:, -1] - window[:, 0]
            else:
                trend = torch.zeros(batch_size, device=device)
            
            # 特征5：价格水平（归一化价格位置）
            price_level = price_norm[:, t]
            
            # 堆叠特征 (batch_size, 5)
            features_t = torch.stack([
                time_position, 
                local_return, 
                local_volatility, 
                trend, 
                price_level
            ], dim=1)
            
            financial_feats.append(features_t)
        
        # (batch_size, seq_len, 5)
        financial_features = torch.stack(financial_feats, dim=1)
        
        return financial_features
    
    def forward(self, lstm_output, price_sequence=None):
        """
        Args:
            lstm_output: (batch_size, seq_len, hidden_size) LSTM隐状态
            price_sequence: (batch_size, seq_len) 原始价格序列
        
        Returns:
            context_vector: (batch_size, hidden_size) 注意力加权的上下文向量
        """
        batch_size, seq_len, _ = lstm_output.shape
        
        # 1. 内容注意力分数
        content_scores = self.content_attention(lstm_output)  # (batch, seq_len, 1)
        
        # 2. 金融特征注意力分数
        if price_sequence is not None:
            financial_features = self.compute_financial_features(price_sequence)
            financial_scores = self.financial_attention(financial_features)  # (batch, seq_len, 1)
        else:
            financial_scores = torch.zeros_like(content_scores)
        
        # 3. 融合两种注意力分数
        # 使用可学习的权重
        alpha_norm = torch.sigmoid(self.alpha)
        beta_norm = torch.sigmoid(self.beta)
        
        combined_scores = alpha_norm * content_scores + beta_norm * financial_scores
        
        # 4. Softmax得到注意力权重
        attention_weights = torch.softmax(combined_scores, dim=1)  # (batch, seq_len, 1)
        
        # 5. 加权求和得到上下文向量
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)  # (batch, hidden_size)
        
        return context_vector

class DirectFinAttLSTM(nn.Module):
    """
    直接预测金融注意力LSTM
    
    架构：
    输入 → 特征提取 → LSTM → 金融注意力 → 全连接 → 输出
    """
    def __init__(self, input_dim, lstm_units=128, dense_units=64, dropout=0.3):
        super(DirectFinAttLSTM, self).__init__()
        
        self.input_dim = input_dim
        
        # LSTM层
        self.lstm = nn.LSTM(input_dim, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        
        # 金融注意力层
        self.attention = FinancialAttentionLayer(lstm_units)
        
        # 全连接层
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x, price_raw=None):
        """
        Args:
            x: (batch_size, seq_len, n_features) 特征序列
            price_raw: (batch_size, seq_len) 原始价格序列（用于金融特征计算）
        """
        # LSTM编码
        lstm_out, _ = self.lstm(x)
        lstm_out = self.dropout1(lstm_out)
        
        # 金融注意力
        context = self.attention(lstm_out, price_raw)
        
        # 全连接预测
        out = self.fc1(context)
        out = torch.relu(out)
        out = self.dropout2(out)
        out = self.fc2(out)
        
        return out.squeeze()

# ============================================================================
# 对比模型：标准LSTM和标准AttLSTM
# ============================================================================

class StandardLSTM(nn.Module):
    """标准LSTM（无注意力）"""
    def __init__(self, input_dim, lstm_units=128, dense_units=64, dropout=0.3):
        super(StandardLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x, price_raw=None):
        lstm_out, (h_n, c_n) = self.lstm(x)
        # 只取最后一个时间步
        last_hidden = h_n[-1]
        last_hidden = self.dropout1(last_hidden)
        out = self.fc1(last_hidden)
        out = torch.relu(out)
        out = self.dropout2(out)
        out = self.fc2(out)
        return out.squeeze()

class StandardAttLSTM(nn.Module):
    """标准AttLSTM（简单注意力）"""
    def __init__(self, input_dim, lstm_units=128, dense_units=64, dropout=0.3):
        super(StandardAttLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.attention = nn.Linear(lstm_units, 1)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x, price_raw=None):
        lstm_out, _ = self.lstm(x)
        lstm_out = self.dropout1(lstm_out)
        
        # 简单注意力
        attn_weights = torch.softmax(self.attention(lstm_out), dim=1)
        context = torch.sum(attn_weights * lstm_out, dim=1)
        
        out = self.fc1(context)
        out = torch.relu(out)
        out = self.dropout2(out)
        out = self.fc2(out)
        return out.squeeze()

# ============================================================================
# 数据准备
# ============================================================================

def prepare_direct_prediction_data(prices, lookback, horizon):
    """
    准备直接预测的数据
    
    Args:
        prices: 原始价格序列
        lookback: 回望窗口
        horizon: 预测horizon（通常为1）
    
    Returns:
        X_price: 原始价格窗口 (n_samples, lookback)
        X_features: 特征矩阵 (n_samples, lookback, n_features)
        y: 目标价格 (n_samples,)
    """
    n = len(prices)
    n_samples = n - lookback - horizon + 1
    
    X_price = []
    X_features = []
    y = []
    
    for i in range(n_samples):
        # 输入：过去lookback天
        window = prices[i:i+lookback]
        X_price.append(window)
        
        # 计算特征
        features = create_financial_features(window)
        X_features.append(features)
        
        # 目标：未来第horizon天
        target = prices[i + lookback + horizon - 1]
        y.append(target)
    
    X_price = np.array(X_price)
    X_features = np.array(X_features)
    y = np.array(y)
    
    return X_price, X_features, y

# ============================================================================
# 训练函数
# ============================================================================

def train_model(model, train_loader, val_loader, model_name):
    """训练模型"""
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR, weight_decay=1e-5)  # 添加L2正则化
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=15
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    print(f"\n{'='*80}")
    print(f"训练模型: {model_name}")
    print(f"{'='*80}")
    print(f"  最大epoch: {EPOCHS}, 早停patience: {PATIENCE}")
    print(f"  学习率: {LR}, 批大小: {BATCH_SIZE}")
    
    for epoch in range(EPOCHS):
        # 训练
        model.train()
        train_loss = 0
        for batch_data in train_loader:
            if len(batch_data) == 3:
                X_batch, y_batch, price_raw_batch = batch_data
                X_batch = X_batch.to(DEVICE)
                y_batch = y_batch.to(DEVICE)
                price_raw_batch = price_raw_batch.to(DEVICE)
            else:
                X_batch, y_batch = batch_data
                X_batch = X_batch.to(DEVICE)
                y_batch = y_batch.to(DEVICE)
                price_raw_batch = None
            
            optimizer.zero_grad()
            y_pred = model(X_batch, price_raw_batch)
            loss = criterion(y_pred, y_batch)
            
            # 检查loss是否为NaN
            if torch.isnan(loss):
                print(f"  警告: 检测到NaN loss，跳过此batch")
                continue
            
            loss.backward()
            
            # 梯度裁剪，防止梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for batch_data in val_loader:
                if len(batch_data) == 3:
                    X_batch, y_batch, price_raw_batch = batch_data
                    X_batch = X_batch.to(DEVICE)
                    y_batch = y_batch.to(DEVICE)
                    price_raw_batch = price_raw_batch.to(DEVICE)
                else:
                    X_batch, y_batch = batch_data
                    X_batch = X_batch.to(DEVICE)
                    y_batch = y_batch.to(DEVICE)
                    price_raw_batch = None
                
                y_pred = model(X_batch, price_raw_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"  Epoch {epoch+1:3d}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}, patience={patience_counter}/{PATIENCE}")
        
        if patience_counter >= PATIENCE:
            print(f"  早停触发: epoch {epoch+1}")
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    print(f"  训练完成！最佳验证loss: {best_val_loss:.6f}")
    
    return model

def evaluate_model(model, test_loader, price_scaler, model_name):
    """评估模型"""
    model.eval()
    predictions = []
    actuals = []
    
    with torch.no_grad():
        for batch_data in test_loader:
            if len(batch_data) == 3:
                X_batch, y_batch, price_raw_batch = batch_data
                X_batch = X_batch.to(DEVICE)
                price_raw_batch = price_raw_batch.to(DEVICE)
            else:
                X_batch, y_batch = batch_data
                X_batch = X_batch.to(DEVICE)
                price_raw_batch = None
            
            y_pred = model(X_batch, price_raw_batch)
            predictions.extend(y_pred.cpu().numpy())
            actuals.extend(y_batch.numpy())
    
    predictions = np.array(predictions)
    actuals = np.array(actuals)
    
    # 反标准化
    predictions = price_scaler.inverse_transform(predictions.reshape(-1, 1)).flatten()
    actuals = price_scaler.inverse_transform(actuals.reshape(-1, 1)).flatten()
    
    # 计算指标
    mae = mean_absolute_error(actuals, predictions)
    rmse = np.sqrt(mean_squared_error(actuals, predictions))
    r2 = r2_score(actuals, predictions)
    mape = np.mean(np.abs((actuals - predictions) / (actuals + 1e-8))) * 100
    
    print(f"\n{model_name} 性能:")
    print(f"  MAE={mae:.4f}, RMSE={rmse:.4f}, R²={r2:.4f}, MAPE={mape:.2f}%")
    
    return {
        'predictions': predictions,
        'actuals': actuals,
        'mae': mae,
        'rmse': rmse,
        'r2': r2,
        'mape': mape
    }

# ============================================================================
# 可视化
# ============================================================================

def plot_results(results, test_dates, output_dir, stock_name):
    """绘制结果对比图"""
    fig, axes = plt.subplots(3, 1, figsize=(16, 12))
    
    models = list(results.keys())
    actuals = results[models[0]]['actuals']
    
    # 子图1：预测曲线对比
    ax1 = axes[0]
    ax1.plot(test_dates, actuals, label='实际价格', color='black', linewidth=2, alpha=0.8)
    
    colors = ['blue', 'green', 'red']
    for i, model_name in enumerate(models):
        ax1.plot(test_dates, results[model_name]['predictions'], 
                label=f'{model_name}', color=colors[i], linewidth=1.5, alpha=0.7)
    
    ax1.set_xlabel('日期', fontsize=12)
    ax1.set_ylabel('价格 (USD)', fontsize=12)
    ax1.set_title('预测曲线对比', fontsize=14, fontweight='bold')
    ax1.legend(loc='best', fontsize=10)
    ax1.grid(True, alpha=0.3)
    ax1.tick_params(axis='x', rotation=45)
    
    # 子图2：误差对比
    ax2 = axes[1]
    for i, model_name in enumerate(models):
        errors = actuals - results[model_name]['predictions']
        ax2.plot(test_dates, errors, label=f'{model_name}', color=colors[i], linewidth=1, alpha=0.7)
    
    ax2.axhline(y=0, color='black', linestyle='--', linewidth=1)
    ax2.set_xlabel('日期', fontsize=12)
    ax2.set_ylabel('预测误差 (USD)', fontsize=12)
    ax2.set_title('预测误差对比', fontsize=14, fontweight='bold')
    ax2.legend(loc='best', fontsize=10)
    ax2.grid(True, alpha=0.3)
    ax2.tick_params(axis='x', rotation=45)
    
    # 子图3：性能指标对比
    ax3 = axes[2]
    metrics = ['MAE', 'RMSE', 'R²', 'MAPE(%)']
    x_pos = np.arange(len(metrics))
    width = 0.25
    
    for i, model_name in enumerate(models):
        values = [
            results[model_name]['mae'],
            results[model_name]['rmse'],
            results[model_name]['r2'],
            results[model_name]['mape']
        ]
        ax3.bar(x_pos + i*width, values, width, label=model_name, color=colors[i], alpha=0.7)
    
    ax3.set_xlabel('指标', fontsize=12)
    ax3.set_ylabel('值', fontsize=12)
    ax3.set_title('性能指标对比', fontsize=14, fontweight='bold')
    ax3.set_xticks(x_pos + width)
    ax3.set_xticklabels(metrics)
    ax3.legend(loc='best', fontsize=10)
    ax3.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    path = os.path.join(output_dir, f'{stock_name}_exp10_direct_prediction.png')
    plt.savefig(path, dpi=300, bbox_inches='tight')
    print(f"\n已保存可视化: {path}")
    plt.close()

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("实验10: 直接预测 - 金融注意力LSTM")
    print("="*80)
    print(f"使用设备: {DEVICE}")
    print(f"回望窗口: {LOOKBACK_WINDOW}天")
    print(f"预测horizon: {PREDICTION_HORIZON}天")
    print(f"金融特征: 价格+收益率+MA+波动率+动量+RSI")
    
    # 1. 加载数据
    print(f"\n{'='*80}")
    print("步骤1: 加载数据")
    print(f"{'='*80}")
    df = pd.read_excel(DATA_PATH, sheet_name='close')
    
    if STOCK_NAME not in df.columns:
        print(f"错误：找不到股票 {STOCK_NAME}")
        return
    
    data = pd.DataFrame({
        'date': pd.to_datetime(df.iloc[:, 0]),
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    
    print(f"  股票: {STOCK_NAME}")
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本数: {len(data)}")
    
    # 2. 准备数据
    print(f"\n{'='*80}")
    print("步骤2: 准备直接预测数据")
    print(f"{'='*80}")
    
    prices = data['close'].values
    dates = data['date'].values
    
    # 创建特征
    X_price, X_features, y = prepare_direct_prediction_data(
        prices, LOOKBACK_WINDOW, PREDICTION_HORIZON
    )
    
    print(f"  样本数: {len(X_price)}")
    print(f"  特征数: {X_features.shape[2]}")
    print(f"  特征维度: {X_features.shape}")
    
    # 3. 分割数据
    train_size = int(len(X_price) * TRAIN_RATIO)
    
    X_price_train = X_price[:train_size]
    X_features_train = X_features[:train_size]
    y_train = y[:train_size]
    
    X_price_test = X_price[train_size:]
    X_features_test = X_features[train_size:]
    y_test = y[train_size:]
    test_dates = dates[train_size + LOOKBACK_WINDOW:]
    
    print(f"\n  训练集: {len(X_price_train)} 样本")
    print(f"  测试集: {len(X_price_test)} 样本")
    
    # 4. 归一化
    print(f"\n{'='*80}")
    print("步骤3: 数据归一化")
    print(f"{'='*80}")
    
    # 价格归一化（只用训练集fit）
    price_scaler = StandardScaler()
    X_price_train_scaled = X_price_train.copy()
    X_price_test_scaled = X_price_test.copy()
    y_train_scaled = price_scaler.fit_transform(y_train.reshape(-1, 1)).flatten()
    y_test_scaled = price_scaler.transform(y_test.reshape(-1, 1)).flatten()
    
    # 特征归一化（按特征维度）
    X_features_train_scaled = X_features_train.copy()
    X_features_test_scaled = X_features_test.copy()
    
    n_features = X_features_train.shape[2]
    feature_scalers = []
    
    for i in range(n_features):
        scaler = StandardScaler()
        # 展平时间维度进行归一化
        train_feat = X_features_train[:, :, i].reshape(-1, 1)
        test_feat = X_features_test[:, :, i].reshape(-1, 1)
        
        train_feat_scaled = scaler.fit_transform(train_feat)
        test_feat_scaled = scaler.transform(test_feat)
        
        X_features_train_scaled[:, :, i] = train_feat_scaled.reshape(X_features_train.shape[0], -1)
        X_features_test_scaled[:, :, i] = test_feat_scaled.reshape(X_features_test.shape[0], -1)
        
        feature_scalers.append(scaler)
    
    print(f"  价格归一化完成")
    print(f"  特征归一化完成 ({n_features}个特征)")
    
    # 5. 创建数据加载器
    train_dataset = StockDataset(X_features_train_scaled, y_train_scaled, X_price_train_scaled)
    train_size_split = int(0.85 * len(train_dataset))
    val_size_split = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size_split]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    
    test_dataset = StockDataset(X_features_test_scaled, y_test_scaled, X_price_test_scaled)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 6. 训练三个模型
    print(f"\n{'='*80}")
    print("步骤4: 训练模型")
    print(f"{'='*80}")
    
    models = {
        'StandardLSTM': StandardLSTM(n_features, LSTM_UNITS, DENSE_UNITS, DROPOUT).to(DEVICE),
        'StandardAttLSTM': StandardAttLSTM(n_features, LSTM_UNITS, DENSE_UNITS, DROPOUT).to(DEVICE),
        'FinAttLSTM': DirectFinAttLSTM(n_features, LSTM_UNITS, DENSE_UNITS, DROPOUT).to(DEVICE)
    }
    
    results = {}
    
    for model_name, model in models.items():
        trained_model = train_model(model, train_loader, val_loader, model_name)
        result = evaluate_model(trained_model, test_loader, price_scaler, model_name)
        results[model_name] = result
    
    # 7. 结果对比
    print(f"\n{'='*80}")
    print("步骤5: 结果对比")
    print(f"{'='*80}")
    
    print(f"\n{'模型':<20} {'MAE':<12} {'RMSE':<12} {'R²':<12} {'MAPE(%)':<12}")
    print("-" * 70)
    
    for model_name, result in results.items():
        print(f"{model_name:<20} {result['mae']:<12.4f} {result['rmse']:<12.4f} {result['r2']:<12.4f} {result['mape']:<12.2f}")
    
    best_model = min(results.keys(), key=lambda k: results[k]['mae'])
    print(f"\n最优模型: {best_model} (MAE={results[best_model]['mae']:.4f})")
    
    # 8. 可视化
    print(f"\n{'='*80}")
    print("步骤6: 生成可视化")
    print(f"{'='*80}")
    plot_results(results, test_dates, OUTPUT_DIR, STOCK_NAME)
    
    # 9. 保存结果
    print(f"\n{'='*80}")
    print("步骤7: 保存结果")
    print(f"{'='*80}")
    
    # 保存预测结果
    results_df = pd.DataFrame({
        'date': test_dates,
        'actual': results['StandardLSTM']['actuals']
    })
    
    for model_name, result in results.items():
        results_df[f'pred_{model_name}'] = result['predictions']
    
    results_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp10_results.csv')
    results_df.to_csv(results_path, index=False)
    print(f"  预测结果已保存: {results_path}")
    
    # 保存性能汇总
    summary_data = []
    for model_name, result in results.items():
        summary_data.append({
            'model': model_name,
            'MAE': result['mae'],
            'RMSE': result['rmse'],
            'R2': result['r2'],
            'MAPE': result['mape']
        })
    
    summary_df = pd.DataFrame(summary_data)
    summary_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp10_summary.csv')
    summary_df.to_csv(summary_path, index=False)
    print(f"  性能汇总已保存: {summary_path}")
    
    print(f"\n{'='*80}")
    print("实验10完成！")
    print(f"{'='*80}")
    print(f"最优模型: {best_model}")
    print(f"MAE: {results[best_model]['mae']:.4f}")
    print(f"RMSE: {results[best_model]['rmse']:.4f}")
    print(f"R²: {results[best_model]['r2']:.4f}")

if __name__ == '__main__':
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"\n实验失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
