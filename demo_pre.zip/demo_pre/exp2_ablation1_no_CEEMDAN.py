"""
消融实验2: Ablation-1 - 去掉CEEMDAN
配置: ReliefF + AttLSTM + PSO

目的: 验证CEEMDAN分解的必要性
方法: 直接对原始价格序列进行预测，不做分解
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import copy

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler

# 特征选择
from skrebate import ReliefF

# 评估指标
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ============================================================================
# 配置参数（与exp1保持一致）
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\prediction_data.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\消融实验\result'

DATA_START = '2015-07-01'
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

MAX_LAG = 10
N_FEATURES_TO_SELECT = 6

CNN_FILTERS = 64
BILSTM_UNITS = 128
GRU_UNITS = 64
DENSE_UNITS = 32
DROPOUT = 0.3
LR = 0.001
BATCH_SIZE = 32
EPOCHS = 200
PATIENCE = 20

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# 模型定义：AttLSTM
# ============================================================================

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Linear(hidden_size, 1)
    
    def forward(self, lstm_output):
        attention_weights = torch.softmax(self.attention(lstm_output), dim=1)
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)
        return context_vector

class AttLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=128, dense_units=32, dropout=0.3):
        super(AttLSTM, self).__init__()
        
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.attention = AttentionLayer(lstm_units)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        x = self.attention(x)
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        return x.squeeze()

# ============================================================================
# 特征工程
# ============================================================================

def create_lagged_features(data, lags):
    """创建滞后特征"""
    max_lag = max(lags)
    n = len(data)
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    
    return X, y

def relieff_feature_selection(data, max_lag=10, n_features_to_select=6):
    """ReliefF特征选择"""
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(data, all_lags)
    
    relieff = ReliefF(n_features_to_select=n_features_to_select, n_neighbors=10)
    relieff.fit(X, y)
    
    selected_indices = relieff.top_features_[:n_features_to_select]
    selected_lags = [all_lags[i] for i in selected_indices]
    selected_lags.sort()
    
    return selected_lags

# ============================================================================
# 训练函数（无数据泄漏）
# ============================================================================

def train_model_no_leakage(price_full, train_size, selected_lags):
    """
    训练模型（无CEEMDAN分解，直接对原始序列建模）
    """
    print(f"  训练集大小: {train_size}, 测试集大小: {len(price_full) - train_size}")
    print(f"  选择的滞后项: {selected_lags}")
    
    # 分割数据
    price_train = price_full[:train_size]
    price_test = price_full[train_size:]
    
    # 只用训练集fit scaler
    scaler = StandardScaler()
    price_train_scaled = scaler.fit_transform(price_train.reshape(-1, 1)).flatten()
    price_test_scaled = scaler.transform(price_test.reshape(-1, 1)).flatten()
    
    # 拼接完整序列
    price_scaled = np.concatenate([price_train_scaled, price_test_scaled])
    
    # 创建滞后特征
    X_full, y_full = create_lagged_features(price_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    print(f"  训练样本数: {len(X_train)}, 测试样本数: {len(X_test)}")
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    val_size_split = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size_split]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 模型
    model = AttLSTM(
        input_dim=len(selected_lags),
        lstm_units=GRU_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', 
                                                      factor=0.5, patience=10)
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    print(f"  开始训练（最大{EPOCHS}个epoch，早停patience={PATIENCE}）...")
    
    for epoch in range(EPOCHS):
        # 训练
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        # 早停
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
            if patience_counter >= PATIENCE:
                print(f"  早停于epoch {epoch+1}")
                break
    
    # 加载最优模型
    model.load_state_dict(best_state)
    model.eval()
    
    # 测试集预测
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch)
            test_pred_scaled.extend(pred.cpu().numpy())
    
    # 反标准化
    test_pred = scaler.inverse_transform(np.array(test_pred_scaled).reshape(-1, 1)).flatten()
    
    print(f"  ✓ 模型预测完成")
    
    return test_pred

# ============================================================================
# 评估指标
# ============================================================================

def calculate_metrics(y_true, y_pred):
    """计算评估指标"""
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    # MAPE
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    # DA (Direction Accuracy)
    y_true_diff = np.diff(y_true)
    y_pred_diff = np.diff(y_pred)
    da = np.mean((y_true_diff * y_pred_diff) > 0) * 100
    
    # TIC (Theil Inequality Coefficient)
    tic = np.sqrt(np.mean((y_true - y_pred)**2)) / (
        np.sqrt(np.mean(y_true**2)) + np.sqrt(np.mean(y_pred**2))
    )
    
    return {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'MAPE': mape,
        'DA': da,
        'TIC': tic
    }

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("消融实验2: Ablation-1 - 去掉CEEMDAN")
    print("配置: ReliefF + AttLSTM + PSO")
    print("="*80)
    print(f"使用设备: {DEVICE}")
    print(f"说明: 不使用CEEMDAN分解，直接对原始序列建模")
    
    # 1. 加载数据
    print(f"\n{'='*80}")
    print("步骤1: 加载数据")
    print(f"{'='*80}")
    
    # 读取数据
    df = pd.read_excel(DATA_PATH)
    
    # 检查列名
    if 'date' not in df.columns or STOCK_NAME not in df.columns:
        print(f"错误：找不到列 'date' 或 '{STOCK_NAME}'")
        print(f"可用列: {df.columns.tolist()}")
        return
    
    data = pd.DataFrame({
        'date': pd.to_datetime(df['date']),
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    data = data.sort_values('date').reset_index(drop=True)
    
    print(f"  股票代码: {STOCK_NAME}")
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本数: {len(data)}")
    
    # 2. 分割数据
    train_size = int(len(data) * TRAIN_RATIO)
    
    print(f"\n{'='*80}")
    print("步骤2: 分割数据")
    print(f"{'='*80}")
    print(f"  训练集: {train_size}样本")
    print(f"  测试集: {len(data) - train_size}样本")
    
    # 3. ReliefF特征选择（只在训练集上）
    print(f"\n{'='*80}")
    print("步骤3: ReliefF特征选择")
    print(f"{'='*80}")
    
    full_prices = data['close'].values
    train_prices = full_prices[:train_size]
    
    selected_lags = relieff_feature_selection(train_prices, MAX_LAG, N_FEATURES_TO_SELECT)
    print(f"  选择的滞后项: {selected_lags}")
    
    # 4. 训练模型
    print(f"\n{'='*80}")
    print("步骤4: 训练AttLSTM模型")
    print(f"{'='*80}")
    
    test_pred = train_model_no_leakage(full_prices, train_size, selected_lags)
    
    # 5. 评估
    print(f"\n{'='*80}")
    print("步骤5: 评估结果")
    print(f"{'='*80}")
    
    max_lag = MAX_LAG
    test_true = full_prices[train_size + max_lag:]
    
    metrics = calculate_metrics(test_true, test_pred)
    
    print(f"\n最终评估指标:")
    print(f"  MAE:  {metrics['MAE']:.4f}")
    print(f"  RMSE: {metrics['RMSE']:.4f}")
    print(f"  R²:   {metrics['R2']:.4f}")
    print(f"  MAPE: {metrics['MAPE']:.2f}%")
    print(f"  DA:   {metrics['DA']:.2f}%")
    print(f"  TIC:  {metrics['TIC']:.4f}")
    
    # 6. 保存结果
    result_df = pd.DataFrame({
        'date': data['date'].iloc[train_size + max_lag:].values,
        'true': test_true,
        'pred': test_pred
    })
    
    save_path = os.path.join(OUTPUT_DIR, 'exp2_ablation1_no_ceemdan_predictions.csv')
    result_df.to_csv(save_path, index=False, encoding='utf-8-sig')
    print(f"\n✓ 预测结果已保存: {save_path}")
    
    # 保存指标
    metrics_df = pd.DataFrame([metrics])
    metrics_df['experiment'] = 'Ablation-1 (No CEEMDAN)'
    metrics_path = os.path.join(OUTPUT_DIR, 'exp2_ablation1_metrics.csv')
    metrics_df.to_csv(metrics_path, index=False, encoding='utf-8-sig')
    print(f"✓ 评估指标已保存: {metrics_path}")
    
    print(f"\n{'='*80}")
    print("实验完成！")
    print(f"{'='*80}")
    
    return metrics

if __name__ == '__main__':
    main()
