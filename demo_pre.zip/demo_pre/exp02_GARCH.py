"""
实验2: GARCH(1,1)模型

传统金融波动率模型基准
"""

import sys
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')  # 忽略所有警告
import os
os.environ['PYTHONWARNINGS'] = 'ignore'  # 忽略所有警告

from common_config import *
from common_utils import *

try:
    from arch import arch_model
except ImportError:
    print("错误: 需要安装arch库: pip install arch")
    sys.exit(1)

def train_and_predict_garch(stock_key):
    """训练GARCH并预测单只股票"""
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    # 使用固定的GARCH(1,1) - 金融波动率建模标准基准
    print(f"使用GARCH(1,1)模型")
    
    # 计算收益率
    train_returns = train_df['close'].pct_change().dropna() * 100
    
    # 训练GARCH模型
    print("训练GARCH模型...")
    model = arch_model(train_returns, vol='Garch', p=GARCH_P, q=GARCH_Q)
    res = model.fit(disp='off', show_warning=False)
    
    # 预测
    print("进行预测...")
    predictions = []
    history_prices = list(train_df['close'].values)
    
    for t in range(len(test_df)):
        # 简单预测：使用最后一个价格
        last_price = history_prices[-1]
        # GARCH预测波动率，这里简化为持续预测
        pred_price = last_price
        predictions.append(pred_price)
        history_prices.append(test_df['close'].values[t])
    
    predictions = np.array(predictions)
    y_true = test_df['close'].values
    
    metrics = calculate_metrics(y_true, predictions)
    print_metrics(metrics, "  ")
    
    output_prefix = get_output_prefix('exp02_GARCH', stock_key)
    
    save_predictions(
        test_df['date'], y_true, predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    save_metrics(
        metrics, 'exp02_GARCH', stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    plot_predictions(
        test_df['date'], y_true, predictions,
        f'GARCH - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验2: GARCH(1,1)模型")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_garch(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验2: GARCH(1,1) 完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
