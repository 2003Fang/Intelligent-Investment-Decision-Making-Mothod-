"""
实验9: CEEMDAN-ReliefF-AttLSTM-NSGA2

完全基于BASE_AttLSTM.py，使用NSGA-2优化集成权重
"""

import sys
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import copy
import warnings
warnings.filterwarnings('ignore')

from common_config import *
from common_utils import *

# 修复PyEMD导入（必须导入class而非module）
from PyEMD.EMD import EMD
import PyEMD
PyEMD.EMD = EMD  # Monkey patch修复内部导入
from PyEMD.CEEMDAN import CEEMDAN

# ============================================================================
# AttLSTM模型定义（与BASE完全相同）
# ============================================================================

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Linear(hidden_size, 1)
    
    def forward(self, lstm_output):
        attention_weights = torch.softmax(self.attention(lstm_output), dim=1)
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)
        return context_vector

class AttLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=64, dense_units=32, dropout=0.3):
        super(AttLSTM, self).__init__()
        
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.attention = AttentionLayer(lstm_units)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        x = self.attention(x)
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        return x.squeeze()

# ============================================================================
# 训练单个IMF（与BASE完全相同）
# ============================================================================

def train_single_imf(imf_train, imf_test, selected_lags):
    # 标准化（只用训练集fit）
    train_scaled, test_scaled, scaler = normalize_data(imf_train, imf_test)
    
    # 拼接完整序列后创建滞后特征（与BASE_AttLSTM.py一致）
    imf_scaled = np.concatenate([train_scaled, test_scaled])
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_size = len(imf_train)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    train_dataset = StockDataset(X_train, y_train)
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    model = AttLSTM(
        input_dim=len(selected_lags),
        lstm_units=LSTM_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if patience_counter >= PATIENCE:
            break
    
    if best_state is not None:
        model.load_state_dict(best_state)
    
    model.eval()
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    test_pred = scaler.inverse_transform(
        np.array(test_pred_scaled).reshape(-1, 1)
    ).flatten()
    
    return test_pred

# ============================================================================
# NSGA-2优化权重（完全参考BASE_AttLSTM.py）
# ============================================================================

def compute_objectives(weights, imf_predictions, true_values):
    """计算两个目标：MAE和Std"""
    weights = clip_weights(weights)
    pred = sum(w * p for w, p in zip(weights, imf_predictions))
    residual = true_values - pred
    mae = np.mean(np.abs(residual))
    std_residual = np.std(residual)
    return mae, std_residual

def nsga2_optimize_weights(imf_predictions, true_values):
    """
    NSGA-2多目标优化（完全参考BASE）
    目标1: MAE（精度）
    目标2: Std（稳定性）
    约束: 0 < wi ≤ 1.5
    """
    print(f"\nNSGA-2优化权重...")
    n_imfs = len(imf_predictions)
    pop_size = NSGA2_POP_SIZE
    max_iter = NSGA2_MAX_ITER
    
    # 初始化种群
    population = []
    for _ in range(pop_size):
        ind = np.random.uniform(0.3, 1.5, n_imfs)
        population.append(clip_weights(ind))
    
    archive = []  # 存储所有非支配解
    
    for iteration in range(max_iter):
        # 计算适应度
        fitness_values = [compute_objectives(ind, imf_predictions, true_values) for ind in population]
        
        # 生成后代（变异）
        offspring = []
        for ind in population:
            if np.random.rand() < 0.9:
                mutant = ind + np.random.normal(0, 0.1, n_imfs)
                mutant = clip_weights(mutant)
                offspring.append(mutant)
        
        # 合并父代和子代
        combined = population + offspring
        combined_fitness = [compute_objectives(ind, imf_predictions, true_values) for ind in combined]
        
        # 非支配排序（简化版：按MAE+Std排序）
        sorted_indices = sorted(range(len(combined)), 
                              key=lambda i: combined_fitness[i][0] + combined_fitness[i][1])
        
        # 选择下一代
        population = [combined[i].copy() for i in sorted_indices[:pop_size]]
        
        # 更新存档（保存前10个非支配解）
        if iteration % 10 == 0:
            archive = [(combined_fitness[i], combined[i].copy()) for i in sorted_indices[:10]]
    
    # 最终适应度
    fitness_values = [compute_objectives(ind, imf_predictions, true_values) for ind in population]
    best_idx = min(range(len(fitness_values)), 
                   key=lambda i: fitness_values[i][0] + fitness_values[i][1])
    optimal_weights = clip_weights(population[best_idx])
    best_objectives = fitness_values[best_idx]
    
    print(f"NSGA-2完成: MAE={best_objectives[0]:.4f}, Std={best_objectives[1]:.4f}")
    print(f"最优权重: {optimal_weights}")
    print(f"权重和: {np.sum(optimal_weights):.4f}")
    
    return optimal_weights

# ============================================================================
# 主函数
# ============================================================================

def train_and_predict_ceemdan_attlstm_nsga2(stock_key):
    """训练主模型并预测单只股票"""
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    prices = df['close'].values
    train_size = len(train_df)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    print("CEEMDAN分解中...")
    ceemdan = CEEMDAN()
    imfs = ceemdan(prices)
    n_imfs = len(imfs)
    print(f"分解完成: {n_imfs}个IMF分量")
    
    print("训练各IMF...")
    imf_test_predictions = []
    
    for i in range(n_imfs):
        print(f"\nIMF{i+1}/{n_imfs}")
        # 切分IMF为训练/测试集
        imf_train = imfs[i][:train_size]
        imf_test = imfs[i][train_size:]
        
        # ReliefF特征选择（只在训练集上）
        selected_lags = relieff_feature_selection(
            imf_train, MAX_LAG, N_FEATURES_TO_SELECT
        )
        print(f"  选择的滞后项: {selected_lags}")
        
        # 训练并预测（使用正确的imf_test）
        test_pred = train_single_imf(imf_train, imf_test, selected_lags)
        imf_test_predictions.append(test_pred)
    
    min_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions = [p[-min_len:] for p in imf_test_predictions]
    test_true = test_df['close'].values[-min_len:]
    test_dates = test_df['date'].values[-min_len:]
    
    optimal_weights = nsga2_optimize_weights(imf_test_predictions, test_true)
    
    predictions = sum(w * p for w, p in zip(optimal_weights, imf_test_predictions))
    
    metrics = calculate_metrics(test_true, predictions)
    print_metrics(metrics, "  ")
    
    output_prefix = get_output_prefix('exp09_CEEMDAN_AttLSTM_NSGA2', stock_key)
    
    save_predictions(
        test_dates, test_true, predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    save_metrics(
        metrics, 'exp09_CEEMDAN_AttLSTM_NSGA2', stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    plot_predictions(
        test_dates, test_true, predictions,
        f'CEEMDAN-AttLSTM-NSGA2 - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验9: CEEMDAN-AttLSTM-NSGA2")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_ceemdan_attlstm_nsga2(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验9完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
