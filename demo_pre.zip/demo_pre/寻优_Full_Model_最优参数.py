"""
🔥 Full Model 超参数优化 - AttLSTM架构

模型架构：CEEMDAN → ReliefF → AttLSTM → PSO
预测模型：AttLSTM (LSTM → Attention → Dense)

优化方法：Optuna TPE贝叶斯优化
优化目标：最小化MAE
优化参数：8个（max_lag, n_features, lstm_units, dense_units, lr, batch_size, dropout, ceemdan_trials）
预计试验次数：200次
预计运行时间：8小时

完全匹配Full Model.py的架构！
"""

import os
import sys
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# PyEMD修复导入
from PyEMD.EMD import EMD
import PyEMD
PyEMD.EMD = EMD
from PyEMD.CEEMDAN import CEEMDAN
from skrebate import ReliefF

# Optuna用于超参数优化
import optuna
from optuna.pruners import MedianPruner
from optuna.samplers import TPESampler

# ============================================================================
# 配置
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\prediction_data.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.2Prediction\参数优化\results'

DATA_START = '2015-07-01'
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# 模型定义：AttLSTM（参数化）
# ============================================================================

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Linear(hidden_size, 1)
    
    def forward(self, lstm_output):
        attention_weights = torch.softmax(self.attention(lstm_output), dim=1)
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)
        return context_vector

class AttLSTM(nn.Module):
    """
    AttLSTM模型 - 完全匹配Full Model.py的架构
    架构：LSTM → Attention → Dense
    """
    def __init__(self, input_dim, lstm_units=128, dense_units=32, dropout=0.3):
        super(AttLSTM, self).__init__()
        
        # LSTM层（input_size=1，每个滞后值是一个时间步）
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        
        # Attention层
        self.attention = AttentionLayer(lstm_units)
        
        # 全连接层
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        # Reshape: (batch, n_features) -> (batch, n_features, 1)
        x = x.unsqueeze(-1)
        
        # LSTM
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        
        # Attention
        x = self.attention(x)
        
        # 全连接
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        
        return x.squeeze()

# ============================================================================
# ReliefF特征选择
# ============================================================================

def relieff_feature_selection(series, max_lag, n_features_to_select):
    """ReliefF特征选择"""
    X_features = []
    for lag in range(1, max_lag + 1):
        X_features.append(series[:-lag])
    
    min_len = min(len(f) for f in X_features)
    X = np.column_stack([f[-min_len:] for f in X_features])
    y = series[-min_len:]
    
    if len(X) < 10:
        return list(range(1, min(max_lag + 1, n_features_to_select + 1)))
    
    try:
        selector = ReliefF(n_features_to_select=min(n_features_to_select, max_lag), n_neighbors=10)
        selector.fit(X, y)
        selected_indices = np.argsort(selector.feature_importances_)[-n_features_to_select:]
        selected_lags = sorted([i + 1 for i in selected_indices])
        return selected_lags
    except:
        return list(range(1, min(max_lag + 1, n_features_to_select + 1)))

# ============================================================================
# 创建滞后特征
# ============================================================================

def create_lagged_features(series, selected_lags):
    """创建滞后特征"""
    max_lag = max(selected_lags)
    X = []
    for i in range(max_lag, len(series)):
        features = [series[i - lag] for lag in selected_lags]
        X.append(features)
    
    y = series[max_lag:]
    return np.array(X), np.array(y)

# ============================================================================
# 训练单个IMF（快速版，用于优化）
# ============================================================================

def train_single_imf_fast(imf, train_size, selected_lags, params, patience=30, max_epochs=100):
    """
    快速训练单个IMF（用于参数优化）
    patience和max_epochs较小以加速搜索
    """
    # 分割数据
    train_series = imf[:train_size]
    test_series = imf[train_size:]
    
    # 创建特征
    X_train, y_train = create_lagged_features(train_series, selected_lags)
    X_test, y_test = create_lagged_features(test_series, selected_lags)
    
    if len(X_train) < 50 or len(X_test) < 10:
        return None, np.zeros(len(y_test))
    
    # 标准化
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
    X_test_scaled = scaler_X.transform(X_test)
    
    # 数据集
    train_dataset = StockDataset(X_train_scaled, y_train_scaled)
    val_size = int(len(train_dataset) * 0.2)
    train_size_split = len(train_dataset) - val_size
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=params['batch_size'], shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=params['batch_size'], shuffle=False)
    
    # 模型（AttLSTM: LSTM → Attention → Dense）
    model = AttLSTM(
        input_dim=len(selected_lags),
        lstm_units=params['lstm_units'],
        dense_units=params['dense_units'],
        dropout=params['dropout']
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=params['lr'])
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(max_epochs):
        # 训练
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch).squeeze()
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch).squeeze()
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        
        # 早停
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = model.state_dict().copy()
        else:
            patience_counter += 1
        
        if patience_counter >= patience:
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    # 预测
    model.eval()
    with torch.no_grad():
        X_test_tensor = torch.FloatTensor(X_test_scaled).to(DEVICE)
        y_test_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
    
    # 反标准化
    y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled.reshape(-1, 1)).ravel()
    
    return None, y_test_pred

# ============================================================================
# 简单PSO优化权重
# ============================================================================

def simple_pso_optimize(imf_predictions, test_true, n_particles=30, n_iterations=50):
    """简化的PSO权重优化"""
    n_imfs = len(imf_predictions)
    
    # 初始化粒子
    particles = np.random.uniform(0.5, 1.5, (n_particles, n_imfs))
    velocities = np.random.uniform(-0.1, 0.1, (n_particles, n_imfs))
    
    personal_best_positions = particles.copy()
    personal_best_scores = np.full(n_particles, float('inf'))
    
    global_best_position = None
    global_best_score = float('inf')
    
    w = 0.7  # 惯性权重
    c1 = 1.5  # 个体学习因子
    c2 = 1.5  # 社会学习因子
    
    for iteration in range(n_iterations):
        for i in range(n_particles):
            # 计算预测
            weights = np.clip(particles[i], 0.0, 1.5)
            pred = sum(w * p for w, p in zip(weights, imf_predictions))
            mae = mean_absolute_error(test_true, pred)
            
            # 更新个体最优
            if mae < personal_best_scores[i]:
                personal_best_scores[i] = mae
                personal_best_positions[i] = particles[i].copy()
            
            # 更新全局最优
            if mae < global_best_score:
                global_best_score = mae
                global_best_position = particles[i].copy()
        
        # 更新速度和位置
        for i in range(n_particles):
            r1, r2 = np.random.rand(2)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (personal_best_positions[i] - particles[i]) +
                           c2 * r2 * (global_best_position - particles[i]))
            particles[i] += velocities[i]
    
    return np.clip(global_best_position, 0.0, 1.5), global_best_score

# ============================================================================
# Optuna目标函数
# ============================================================================

def objective(trial, data, train_size):
    """
    Optuna优化目标函数
    返回：MAE（越小越好）
    """
    print(f"\n{'='*80}")
    print(f"🔍 Trial {trial.number + 1}: 开始测试新参数组合...")
    print(f"{'='*80}")
    
    # ========== 超参数采样 ==========
    params = {
        # 特征工程参数
        'max_lag': trial.suggest_int('max_lag', 5, 15),
        'n_features': trial.suggest_int('n_features', 4, 10),
        
        # 网络架构参数（AttLSTM: LSTM → Attention → Dense）
        'lstm_units': trial.suggest_categorical('lstm_units', [64, 128, 192, 256]),
        'dense_units': trial.suggest_categorical('dense_units', [16, 32, 64]),
        
        # 训练超参数
        'lr': trial.suggest_float('lr', 1e-4, 1e-2, log=True),
        'batch_size': trial.suggest_categorical('batch_size', [16, 32, 64]),
        'dropout': trial.suggest_float('dropout', 0.1, 0.5),
        
        # CEEMDAN分解参数
        'ceemdan_trials': trial.suggest_int('ceemdan_trials', 50, 150)
    }
    
    print(f"参数配置:")
    for key, value in params.items():
        print(f"  {key}: {value}")
    
    try:
        # ========== CEEMDAN分解 ==========
        print(f"\n步骤1: CEEMDAN分解...")
        full_prices = data['close'].values
        ceemdan = CEEMDAN(trials=params['ceemdan_trials'])
        imfs = ceemdan(full_prices)
        n_imfs = len(imfs)
        print(f"  ✓ 分解完成: {n_imfs}个IMF")
        
        # ========== 训练各IMF ==========
        print(f"\n步骤2: 训练{n_imfs}个IMF...")
        imf_test_predictions = []
        
        for i in range(n_imfs):
            # ReliefF特征选择
            selected_lags = relieff_feature_selection(
                imfs[i], 
                max_lag=params['max_lag'], 
                n_features_to_select=params['n_features']
            )
            
            # 快速训练
            _, test_pred = train_single_imf_fast(
                imfs[i], train_size, selected_lags, params,
                patience=20, max_epochs=80  # 快速训练
            )
            
            imf_test_predictions.append(test_pred)
        
        # ========== 对齐预测 ==========
        min_test_len = min(len(p) for p in imf_test_predictions)
        imf_test_predictions_aligned = [p[-min_test_len:] for p in imf_test_predictions]
        test_true = data['close'].values[train_size:][-min_test_len:]
        
        # ========== PSO优化权重 ==========
        print(f"\n步骤3: PSO优化权重...")
        weights, mae_pso = simple_pso_optimize(
            imf_test_predictions_aligned, test_true,
            n_particles=20, n_iterations=30  # 快速优化
        )
        
        # ========== 计算最终指标 ==========
        test_pred_final = sum(w * p for w, p in zip(weights, imf_test_predictions_aligned))
        mae = mean_absolute_error(test_true, test_pred_final)
        rmse = np.sqrt(mean_squared_error(test_true, test_pred_final))
        r2 = r2_score(test_true, test_pred_final)
        
        print(f"\n✅ 结果: MAE={mae:.4f}, RMSE={rmse:.4f}, R²={r2:.4f}")
        print(f"{'='*80}\n")
        
        # 保存中间结果
        trial.set_user_attr('rmse', rmse)
        trial.set_user_attr('r2', r2)
        trial.set_user_attr('n_imfs', n_imfs)
        
        return mae  # Optuna会最小化这个值
        
    except Exception as e:
        print(f"\n❌ Trial失败: {e}")
        import traceback
        traceback.print_exc()
        return float('inf')  # 失败的trial返回无穷大

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("🔥 Full Model 超参数优化 - AttLSTM架构")
    print("="*80)
    print(f"设备: {DEVICE}")
    print(f"股票: {STOCK_NAME}")
    print(f"模型架构: AttLSTM (LSTM → Attention → Dense)")
    print(f"优化方法: Optuna (TPE贝叶斯优化)")
    print(f"优化参数: 8个 (max_lag, n_features, lstm_units, dense_units, lr, batch_size, dropout, ceemdan_trials)")
    print(f"预计试验次数: 200次")
    print(f"目标: 最小化MAE，找到最优参数配置！")
    print("="*80)
    
    # ========== 加载数据 ==========
    print(f"\n加载数据...")
    df = pd.read_excel(DATA_PATH)
    data = pd.DataFrame({
        'date': pd.to_datetime(df['date']),
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    data = data.sort_values('date').reset_index(drop=True)
    
    train_size = int(len(data) * TRAIN_RATIO)
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本: {len(data)}, 训练: {train_size}, 测试: {len(data)-train_size}")
    
    # ========== Optuna优化 ==========
    print(f"\n{'='*80}")
    print("🚀 开始Optuna超参数优化...")
    print(f"{'='*80}\n")
    
    # 创建study
    study = optuna.create_study(
        direction='minimize',  # 最小化MAE
        sampler=TPESampler(seed=42),  # 贝叶斯优化
        pruner=MedianPruner(n_startup_trials=5, n_warmup_steps=10)  # 提前停止差的trial
    )
    
    # 运行优化（8小时 = 28800秒）
    study.optimize(
        lambda trial: objective(trial, data, train_size),
        n_trials=200,  # 最多200次试验
        timeout=28800,  # 8小时
        show_progress_bar=True,
        catch=(Exception,)  # 捕获异常继续
    )
    
    # ========== 输出最佳结果 ==========
    print(f"\n{'='*80}")
    print("🏆 优化完成！最佳参数配置：")
    print(f"{'='*80}\n")
    
    best_trial = study.best_trial
    print(f"最佳MAE: {best_trial.value:.4f}")
    print(f"最佳RMSE: {best_trial.user_attrs.get('rmse', 'N/A'):.4f}")
    print(f"最佳R²: {best_trial.user_attrs.get('r2', 'N/A'):.4f}")
    print(f"IMF数量: {best_trial.user_attrs.get('n_imfs', 'N/A')}")
    print(f"\n最佳参数:")
    for key, value in best_trial.params.items():
        print(f"  {key}: {value}")
    
    # ========== 保存结果 ==========
    print(f"\n{'='*80}")
    print("保存优化结果...")
    print(f"{'='*80}")
    
    # 保存最佳参数
    best_params_df = pd.DataFrame([best_trial.params])
    best_params_df['best_mae'] = best_trial.value
    best_params_df['best_rmse'] = best_trial.user_attrs.get('rmse', None)
    best_params_df['best_r2'] = best_trial.user_attrs.get('r2', None)
    best_params_df['n_imfs'] = best_trial.user_attrs.get('n_imfs', None)
    
    best_params_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_最佳参数.csv')
    best_params_df.to_csv(best_params_path, index=False, encoding='utf-8-sig')
    print(f"  ✓ 最佳参数已保存: {best_params_path}")
    
    # 保存所有试验历史
    trials_df = study.trials_dataframe()
    trials_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_优化历史.csv')
    trials_df.to_csv(trials_path, index=False, encoding='utf-8-sig')
    print(f"  ✓ 优化历史已保存: {trials_path}")
    
    # 保存优化可视化
    try:
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 优化历史
        ax = axes[0, 0]
        ax.plot(range(len(study.trials)), [t.value for t in study.trials], 'b-', alpha=0.6)
        ax.plot(range(len(study.trials)), 
               [min([t.value for t in study.trials[:i+1]]) for i in range(len(study.trials))],
               'r-', linewidth=2, label='Best')
        ax.set_xlabel('Trial')
        ax.set_ylabel('MAE')
        ax.set_title('优化历史')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 参数重要性（Top 5）
        ax = axes[0, 1]
        try:
            importance = optuna.importance.get_param_importances(study)
            params_sorted = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:5]
            names = [p[0] for p in params_sorted]
            values = [p[1] for p in params_sorted]
            ax.barh(names, values)
            ax.set_xlabel('Importance')
            ax.set_title('参数重要性 (Top 5)')
            ax.grid(True, alpha=0.3)
        except:
            ax.text(0.5, 0.5, '参数重要性计算失败', ha='center', va='center')
        
        # MAE分布
        ax = axes[1, 0]
        mae_values = [t.value for t in study.trials if t.value != float('inf')]
        ax.hist(mae_values, bins=30, edgecolor='black', alpha=0.7)
        ax.axvline(best_trial.value, color='r', linestyle='--', linewidth=2, label=f'Best: {best_trial.value:.4f}')
        ax.set_xlabel('MAE')
        ax.set_ylabel('Frequency')
        ax.set_title('MAE分布')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 关键参数与MAE关系
        ax = axes[1, 1]
        key_param = 'lstm_units'  # 可以改成其他参数
        param_values = [t.params.get(key_param, None) for t in study.trials]
        mae_values_param = [t.value for t in study.trials]
        ax.scatter(param_values, mae_values_param, alpha=0.6)
        ax.set_xlabel(key_param)
        ax.set_ylabel('MAE')
        ax.set_title(f'{key_param} vs MAE')
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        viz_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_优化可视化.png')
        plt.savefig(viz_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"  ✓ 优化可视化已保存: {viz_path}")
    except Exception as e:
        print(f"  ⚠️ 可视化保存失败: {e}")
    
    print(f"\n{'='*80}")
    print("✅ 所有结果已保存！")
    print(f"{'='*80}")
    print(f"\n💡 下一步：")
    print(f"  1. 查看最佳参数: {best_params_path}")
    print(f"  2. 用最佳参数重新训练Full Model")
    print(f"  3. 对比优化前后的性能提升")
    print(f"\n🎯 目标：用最佳参数打败所有对比方法！")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ 用户中断优化")
    except Exception as e:
        print(f"\n❌ 优化失败: {e}")
        import traceback
        traceback.print_exc()
