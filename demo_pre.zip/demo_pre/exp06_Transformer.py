"""
实验6: Transformer模型
"""

import sys
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import copy
import warnings
warnings.filterwarnings('ignore')

from common_config import *
from common_utils import *

class SimpleTransformer(nn.Module):
    def __init__(self, input_dim, d_model=64, nhead=4, dropout=0.3):
        super(SimpleTransformer, self).__init__()
        
        self.embedding = nn.Linear(1, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, 
            nhead=nhead,
            dim_feedforward=128,
            dropout=dropout,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.fc = nn.Linear(d_model, 1)
    
    def forward(self, x):
        x = self.embedding(x)
        x = self.transformer(x)
        x = x[:, -1, :]  # 取最后一个时间步
        x = self.fc(x)
        return x.squeeze()

def train_transformer(train_loader, val_loader, input_dim):
    model = SimpleTransformer(
        input_dim=input_dim,
        d_model=LSTM_UNITS,
        nhead=4,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"  Epoch {epoch+1}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}")
        
        if patience_counter >= PATIENCE:
            print(f"  早停: epoch {epoch+1}")
            break
    
    if best_state is not None:
        model.load_state_dict(best_state)
    
    return model

def train_and_predict_transformer(stock_key):
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    print("ReliefF特征选择...")
    selected_lags = relieff_feature_selection(
        train_df['close'].values, MAX_LAG, N_FEATURES_TO_SELECT
    )
    print(f"选择的滞后项: {selected_lags}")
    
    train_scaled, test_scaled, scaler = normalize_data(
        train_df['close'].values,
        test_df['close'].values
    )
    
    X_train, y_train = create_lagged_features(train_scaled, selected_lags)
    X_test, y_test = create_lagged_features(test_scaled, selected_lags)
    
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    train_dataset = StockDataset(X_train, y_train)
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    print("训练Transformer模型...")
    model = train_transformer(train_loader, val_loader, len(selected_lags))
    
    print("进行预测...")
    model.eval()
    predictions_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            predictions_scaled.extend(pred)
    
    predictions = scaler.inverse_transform(
        np.array(predictions_scaled).reshape(-1, 1)
    ).flatten()
    
    max_lag = max(selected_lags)
    y_true = test_df['close'].values[max_lag:]
    test_dates = test_df['date'].values[max_lag:]
    
    metrics = calculate_metrics(y_true, predictions)
    print_metrics(metrics, "  ")
    
    output_prefix = get_output_prefix('exp06_Transformer', stock_key)
    
    save_predictions(
        test_dates, y_true, predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    save_metrics(
        metrics, 'exp06_Transformer', stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    plot_predictions(
        test_dates, y_true, predictions,
        f'Transformer - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验6: Transformer模型")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_transformer(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验6完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
