"""
Exp-2: EMD + ReliefF + AttLSTM + PSO

对比实验：验证CEEMDAN相对于EMD的优势
- 使用EMD（Empirical Mode Decomposition）分解
- 保留ReliefF特征选择、AttLSTM模型、单目标PSO优化
- 与Full Model (CEEMDAN)对比
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import copy

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler

# 信号分解和特征选择
from PyEMD.EMD import EMD
from skrebate import ReliefF

# 评估指标
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ============================================================================
# 配置参数
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\prediction_data.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\组件对比实验\分解算法对比\result'

DATA_START = '2015-07-01'
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

MAX_LAG = 10
N_FEATURES_TO_SELECT = 6

GRU_UNITS = 64
DENSE_UNITS = 32
DROPOUT = 0.3
LR = 0.001
BATCH_SIZE = 32
EPOCHS = 200
PATIENCE = 20

# PSO参数
PSO_POP_SIZE = 50
PSO_MAX_ITER = 100

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# 模型定义：AttLSTM
# ============================================================================

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Linear(hidden_size, 1)
    
    def forward(self, lstm_output):
        attention_weights = torch.softmax(self.attention(lstm_output), dim=1)
        context_vector = torch.sum(attention_weights * lstm_output, dim=1)
        return context_vector

class AttLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=128, dense_units=32, dropout=0.3):
        super(AttLSTM, self).__init__()
        
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.attention = AttentionLayer(lstm_units)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        x = self.attention(x)
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        return x.squeeze()

# ============================================================================
# 特征工程
# ============================================================================

def create_lagged_features(data, lags):
    """创建滞后特征"""
    max_lag = max(lags)
    n = len(data)
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    
    return X, y

def relieff_feature_selection(imf, max_lag=10, n_features_to_select=6):
    """ReliefF特征选择"""
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(imf, all_lags)
    
    relieff = ReliefF(n_features_to_select=n_features_to_select, n_neighbors=10)
    relieff.fit(X, y)
    
    selected_indices = relieff.top_features_[:n_features_to_select]
    selected_lags = [all_lags[i] for i in selected_indices]
    selected_lags.sort()
    
    return selected_lags

# ============================================================================
# 训练函数（无数据泄漏）
# ============================================================================

def train_single_imf_no_leakage(imf_full, train_size, selected_lags, imf_idx):
    """训练单个IMF（无数据泄漏）"""
    print(f"  训练集大小: {train_size}, 测试集大小: {len(imf_full) - train_size}")
    print(f"  选择的滞后项: {selected_lags}")
    
    # 分割数据
    imf_train = imf_full[:train_size]
    imf_test = imf_full[train_size:]
    
    # 只用训练集fit scaler
    scaler = StandardScaler()
    imf_train_scaled = scaler.fit_transform(imf_train.reshape(-1, 1)).flatten()
    imf_test_scaled = scaler.transform(imf_test.reshape(-1, 1)).flatten()
    
    # 拼接完整序列
    imf_scaled = np.concatenate([imf_train_scaled, imf_test_scaled])
    
    # 创建滞后特征
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    print(f"  训练样本数: {len(X_train)}, 测试样本数: {len(X_test)}")
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    val_size_split = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size_split]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 模型
    model = AttLSTM(
        input_dim=len(selected_lags),
        lstm_units=GRU_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', 
                                                      factor=0.5, patience=10)
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(EPOCHS):
        # 训练
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"    Epoch {epoch+1:3d}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}, patience={patience_counter}/{PATIENCE}")
        
        if patience_counter >= PATIENCE:
            print(f"  ✓ 早停触发: epoch {epoch+1}")
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    # 预测
    model.eval()
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    # 反标准化
    test_pred = scaler.inverse_transform(np.array(test_pred_scaled).reshape(-1, 1)).flatten()
    
    print(f"  ✓ IMF{imf_idx+1} 预测完成")
    
    return test_pred

# ============================================================================
# 单目标PSO优化
# ============================================================================

def pso_optimize_weights(imf_predictions, true_values, w_min=1e-6, w_max=1.5,
                         pop_size=50, max_iter=100):
    """单目标PSO优化（最小化MAE）"""
    print("  🔄 PSO优化中...")
    n_imfs = len(imf_predictions)
    
    # 初始化粒子和速度
    particles = np.random.uniform(0.5, 1.5, size=(pop_size, n_imfs))
    velocities = np.random.uniform(-0.1, 0.1, size=(pop_size, n_imfs))
    
    # 初始化个体最优
    pbest = particles.copy()
    pbest_fitness = np.array([
        mean_absolute_error(true_values, sum(w * p for w, p in zip(particle, imf_predictions)))
        for particle in particles
    ])
    
    # 初始化全局最优
    gbest_idx = np.argmin(pbest_fitness)
    gbest = pbest[gbest_idx].copy()
    gbest_fitness = pbest_fitness[gbest_idx]
    
    # PSO参数
    w = 0.7
    c1 = 1.5
    c2 = 1.5
    
    for iteration in range(max_iter):
        for i in range(pop_size):
            # 更新速度
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (pbest[i] - particles[i]) +
                           c2 * r2 * (gbest - particles[i]))
            
            # 更新位置
            particles[i] = particles[i] + velocities[i]
            particles[i] = np.clip(particles[i], w_min, w_max)
            
            # 计算适应度
            pred = sum(w * p for w, p in zip(particles[i], imf_predictions))
            fitness = mean_absolute_error(true_values, pred)
            
            # 更新个体最优
            if fitness < pbest_fitness[i]:
                pbest[i] = particles[i].copy()
                pbest_fitness[i] = fitness
                
                # 更新全局最优
                if fitness < gbest_fitness:
                    gbest = particles[i].copy()
                    gbest_fitness = fitness
    
    optimal_weights = np.clip(gbest, w_min, w_max)
    
    print(f"  ✅ PSO完成: MAE={gbest_fitness:.4f}")
    
    return optimal_weights, gbest_fitness

# ============================================================================
# 评估指标
# ============================================================================

def calculate_metrics(y_true, y_pred):
    """计算评估指标"""
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    # MAPE
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    # DA (Direction Accuracy)
    y_true_diff = np.diff(y_true)
    y_pred_diff = np.diff(y_pred)
    da = np.mean((y_true_diff * y_pred_diff) > 0) * 100
    
    # TIC (Theil Inequality Coefficient)
    tic = np.sqrt(np.mean((y_true - y_pred)**2)) / (
        np.sqrt(np.mean(y_true**2)) + np.sqrt(np.mean(y_pred**2))
    )
    
    return {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'MAPE': mape,
        'DA': da,
        'TIC': tic
    }

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("Exp-2: EMD + ReliefF + AttLSTM + PSO")
    print("="*80)
    print(f"使用设备: {DEVICE}")
    print("实验目的: 验证CEEMDAN相对于EMD的优势")
    
    # 1. 加载数据
    print(f"\n{'='*80}")
    print("步骤1: 加载数据")
    print(f"{'='*80}")
    df = pd.read_excel(DATA_PATH)
    
    if 'date' not in df.columns or STOCK_NAME not in df.columns:
        print(f"错误：找不到列 'date' 或 '{STOCK_NAME}'")
        print(f"可用列: {df.columns.tolist()}")
        return
    
    data = pd.DataFrame({
        'date': pd.to_datetime(df['date']),
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    data = data.sort_values('date').reset_index(drop=True)
    
    print(f"  股票代码: {STOCK_NAME}")
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本数: {len(data)}")
    
    # 2. 分割数据
    train_size = int(len(data) * TRAIN_RATIO)
    train_data = data.iloc[:train_size]
    test_data = data.iloc[train_size:]
    
    print(f"\n{'='*80}")
    print("步骤2: 分割数据")
    print(f"{'='*80}")
    print(f"  训练集: {train_data['date'].min()} ~ {train_data['date'].max()} ({len(train_data)}样本)")
    print(f"  测试集: {test_data['date'].min()} ~ {test_data['date'].max()} ({len(test_data)}样本)")
    
    # 3. EMD分解
    print(f"\n{'='*80}")
    print("步骤3: EMD分解")
    print(f"{'='*80}")
    full_prices = data['close'].values
    emd = EMD()
    imfs = emd(full_prices)
    n_imfs = len(imfs)
    print(f"  ✓ 分解完成: {n_imfs}个IMF分量")
    
    # 4. 训练各个IMF
    print(f"\n{'='*80}")
    print("步骤4: ReliefF特征选择 + AttLSTM训练")
    print(f"{'='*80}")
    
    imf_test_predictions = []
    
    for i in range(n_imfs):
        print(f"\n--- IMF{i+1}/{n_imfs} ---")
        selected_lags = relieff_feature_selection(
            imfs[i], max_lag=MAX_LAG, n_features_to_select=N_FEATURES_TO_SELECT
        )
        
        test_pred = train_single_imf_no_leakage(
            imfs[i], train_size, selected_lags, i
        )
        
        imf_test_predictions.append(test_pred)
    
    # 5. 对齐预测长度
    print(f"\n{'='*80}")
    print("步骤5: 对齐预测长度")
    print(f"{'='*80}")
    min_test_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions_aligned = [p[-min_test_len:] for p in imf_test_predictions]
    
    test_true = test_data['close'].values[-min_test_len:]
    test_dates = test_data['date'].values[-min_test_len:]
    
    print(f"  对齐后测试预测长度: {min_test_len}")
    
    # 6. PSO优化权重
    print(f"\n{'='*80}")
    print("步骤6: PSO优化权重")
    print(f"{'='*80}")
    
    weights, mae_pso = pso_optimize_weights(
        imf_test_predictions_aligned, test_true,
        pop_size=PSO_POP_SIZE, max_iter=PSO_MAX_ITER
    )
    
    print(f"  ✅ 优化权重: {[f'{w:.4f}' for w in weights]}")
    
    # 7. 最终预测
    test_pred = sum(w * p for w, p in zip(weights, imf_test_predictions_aligned))
    
    # 8. 评估
    print(f"\n{'='*80}")
    print("步骤7: 评估")
    print(f"{'='*80}")
    
    metrics = calculate_metrics(test_true, test_pred)
    
    print(f"\n实验结果 (Exp-2: EMD):")
    print(f"  MAE   = {metrics['MAE']:.4f}")
    print(f"  RMSE  = {metrics['RMSE']:.4f}")
    print(f"  R²    = {metrics['R2']:.4f}")
    print(f"  MAPE  = {metrics['MAPE']:.2f}%")
    print(f"  DA    = {metrics['DA']:.2f}%")
    print(f"  TIC   = {metrics['TIC']:.4f}")
    
    # 9. 保存结果
    print(f"\n{'='*80}")
    print("步骤8: 保存结果")
    print(f"{'='*80}")
    
    # 预测结果
    result_df = pd.DataFrame({
        'date': test_dates,
        'actual': test_true,
        'pred': test_pred
    })
    
    save_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp2_EMD_predictions.csv')
    result_df.to_csv(save_path, index=False, encoding='utf-8-sig')
    print(f"  ✓ 预测结果已保存: {save_path}")
    
    # 评估指标
    metrics_df = pd.DataFrame([metrics])
    metrics_df['experiment'] = 'Exp-2: EMD'
    metrics_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp2_metrics.csv')
    metrics_df.to_csv(metrics_path, index=False, encoding='utf-8-sig')
    print(f"  ✓ 评估指标已保存: {metrics_path}")
    
    # 权重
    weights_df = pd.DataFrame({
        'IMF': [f'IMF{i+1}' for i in range(len(weights))],
        'Weight': weights
    })
    weights_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp2_weights.csv')
    weights_df.to_csv(weights_path, index=False, encoding='utf-8-sig')
    print(f"  ✓ 权重已保存: {weights_path}")
    
    print(f"\n{'='*80}")
    print("✅ Exp-2完成！")
    print(f"{'='*80}")

if __name__ == '__main__':
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 实验失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
