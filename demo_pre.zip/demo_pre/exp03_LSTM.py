"""
实验3: LSTM模型

基础深度学习模型
"""

import sys
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import copy
import warnings
warnings.filterwarnings('ignore')

from common_config import *
from common_utils import *

# ============================================================================
# LSTM模型定义
# ============================================================================

class SimpleLSTM(nn.Module):
    def __init__(self, input_dim, hidden_size=64, dense_units=32, dropout=0.3):
        super(SimpleLSTM, self).__init__()
        
        self.lstm = nn.LSTM(1, hidden_size, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        
        self.fc1 = nn.Linear(hidden_size, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        # LSTM
        _, (h_n, _) = self.lstm(x)
        h_n = h_n[-1]  # 取最后一层的隐状态
        h_n = self.dropout1(h_n)
        
        # 全连接
        x = self.fc1(h_n)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        
        return x.squeeze()

# ============================================================================
# 训练函数
# ============================================================================

def train_lstm(train_loader, val_loader, input_dim):
    """训练LSTM模型"""
    model = SimpleLSTM(
        input_dim=input_dim,
        hidden_size=LSTM_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(EPOCHS):
        # 训练
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"  Epoch {epoch+1}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}")
        
        if patience_counter >= PATIENCE:
            print(f"  早停: epoch {epoch+1}")
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    return model

# ============================================================================
# 主函数
# ============================================================================

def train_and_predict_lstm(stock_key):
    """训练LSTM并预测单只股票"""
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    # 加载数据
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    # 分割数据
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    # ReliefF特征选择
    print("ReliefF特征选择...")
    selected_lags = relieff_feature_selection(
        train_df['close'].values, MAX_LAG, N_FEATURES_TO_SELECT
    )
    print(f"选择的滞后项: {selected_lags}")
    
    # 标准化
    train_scaled, test_scaled, scaler = normalize_data(
        train_df['close'].values,
        test_df['close'].values
    )
    
    # 创建滞后特征
    X_train, y_train = create_lagged_features(train_scaled, selected_lags)
    X_test, y_test = create_lagged_features(test_scaled, selected_lags)
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 训练模型
    print("训练LSTM模型...")
    model = train_lstm(train_loader, val_loader, len(selected_lags))
    
    # 预测
    print("进行预测...")
    model.eval()
    predictions_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            predictions_scaled.extend(pred)
    
    # 反标准化
    predictions = scaler.inverse_transform(
        np.array(predictions_scaled).reshape(-1, 1)
    ).flatten()
    
    # 获取对齐的真实值和日期
    max_lag = max(selected_lags)
    y_true = test_df['close'].values[max_lag:]
    test_dates = test_df['date'].values[max_lag:]
    
    # 计算指标
    metrics = calculate_metrics(y_true, predictions)
    print_metrics(metrics, "  ")
    
    # 保存结果
    output_prefix = get_output_prefix('exp03_LSTM', stock_key)
    
    save_predictions(
        test_dates,
        y_true,
        predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    save_metrics(
        metrics,
        'exp03_LSTM',
        stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    plot_predictions(
        test_dates,
        y_true,
        predictions,
        f'LSTM - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验3: LSTM模型")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_lstm(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验3完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
