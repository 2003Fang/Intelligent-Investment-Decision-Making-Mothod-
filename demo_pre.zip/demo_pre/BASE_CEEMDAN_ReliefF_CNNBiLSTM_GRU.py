"""实验2：完整版模型（无数据泄漏 + 权重上限1.5）

改进点：
1. ✅ 添加中文字体支持
2. ✅ IMF权重上限从1.0提升到1.5
3. ✅ 无数据泄漏（只用训练集fit scaler）

预期：权重上限放宽可能带来性能提升
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import copy

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 黑体
plt.rcParams['axes.unicode_minus'] = False    # 负号正常显示

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler

# 信号分解和特征选择
from PyEMD import CEEMDAN
from skrebate import ReliefF

# 评估指标
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 优化算法
from scipy.optimize import differential_evolution, minimize
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.problem import Problem
from pymoo.optimize import minimize as pymoo_minimize

# ============================================================================
# 配置参数
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\portfolio\dataset\SP_original\SP_factor.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\11.26prediction\comparison\without_leakage\results'

DATA_START = '2015-07-01'  # 与原始实验保持一致
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

MAX_LAG = 10
N_FEATURES_TO_SELECT = 6

CNN_FILTERS = 64
BILSTM_UNITS = 128
GRU_UNITS = 64
DENSE_UNITS = 32
DROPOUT = 0.3
LR = 0.001
BATCH_SIZE = 32
EPOCHS = 200
PATIENCE = 20

# 优化算法参数
OPT_POP_SIZE = 100
OPT_MAX_ITER = 100
OPT_ARCHIVE_SIZE = 150

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# 模型定义
# ============================================================================

class CNNBiLSTMGRU(nn.Module):
    def __init__(self, input_dim, cnn_filters=64, bilstm_units=128, gru_units=64, dense_units=32, dropout=0.3):
        super(CNNBiLSTMGRU, self).__init__()
        
        self.conv1 = nn.Conv1d(1, cnn_filters, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(cnn_filters)
        self.relu = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)
        
        self.bilstm = nn.LSTM(cnn_filters, bilstm_units, batch_first=True, bidirectional=True)
        self.dropout2 = nn.Dropout(dropout)
        
        self.gru = nn.GRU(bilstm_units * 2, gru_units, batch_first=True)
        self.dropout3 = nn.Dropout(dropout)
        
        self.fc1 = nn.Linear(gru_units, dense_units)
        self.dropout4 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.dropout1(x)
        
        x = x.permute(0, 2, 1)
        x, _ = self.bilstm(x)
        x = self.dropout2(x)
        
        x, _ = self.gru(x)
        x = self.dropout3(x)
        
        x = x[:, -1, :]
        x = self.fc1(x)
        x = self.relu(x)
        x = self.dropout4(x)
        x = self.fc2(x)
        
        return x.squeeze()

# ============================================================================
# 特征工程
# ============================================================================

def create_lagged_features(data, lags):
    max_lag = max(lags)
    n = len(data)
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    
    return X, y

def relieff_feature_selection(imf, max_lag=10, n_features_to_select=6):
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(imf, all_lags)
    
    relieff = ReliefF(n_features_to_select=n_features_to_select, n_neighbors=10)
    relieff.fit(X, y)
    
    selected_indices = relieff.top_features_[:n_features_to_select]
    selected_lags = [all_lags[i] for i in selected_indices]
    selected_lags.sort()
    
    return selected_lags

# ============================================================================
# ✅ 修正版训练函数：无数据泄漏
# ============================================================================

def train_single_imf_no_leakage(imf_full, train_size, selected_lags, imf_idx):
    """
    ✅ 修正版：只用训练集fit scaler，测试集只transform
    """
    print(f"  训练集大小: {train_size}")
    print(f"  测试集大小: {len(imf_full) - train_size}")
    print(f"  选择的滞后项: {selected_lags}")
    
    # ✅ 修正：先分割，再分别标准化
    imf_train = imf_full[:train_size]
    imf_test = imf_full[train_size:]
    
    # 只用训练集fit scaler
    scaler = StandardScaler()
    imf_train_scaled = scaler.fit_transform(imf_train.reshape(-1, 1)).flatten()
    
    # 测试集只transform（不fit）
    imf_test_scaled = scaler.transform(imf_test.reshape(-1, 1)).flatten()
    
    # 重新拼接为完整序列
    imf_scaled = np.concatenate([imf_train_scaled, imf_test_scaled])
    
    # 创建滞后特征
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    print(f"  训练样本数: {len(X_train)}, 测试样本数: {len(X_test)}")
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    val_size_split = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size_split]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 模型
    model = CNNBiLSTMGRU(
        input_dim=len(selected_lags),
        cnn_filters=CNN_FILTERS,
        bilstm_units=BILSTM_UNITS,
        gru_units=GRU_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', 
                                                      factor=0.5, patience=10)
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    print(f"\n  开始训练（最大{EPOCHS}个epoch，早停patience={PATIENCE}）...")
    
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"    Epoch {epoch+1:3d}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}, patience={patience_counter}/{PATIENCE}")
        
        if patience_counter >= PATIENCE:
            print(f"  ✓ 早停触发: epoch {epoch+1}")
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    # 预测
    model.eval()
    train_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=False):
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            train_pred_scaled.extend(pred)
    
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    # ✅ 关键：反标准化回原始空间
    train_pred = scaler.inverse_transform(np.array(train_pred_scaled).reshape(-1, 1)).flatten()
    test_pred = scaler.inverse_transform(np.array(test_pred_scaled).reshape(-1, 1)).flatten()
    
    print(f"  ✓ IMF{imf_idx+1} 预测完成")
    
    return train_pred, test_pred

# ============================================================================
# 优化算法（完整实现，与原版一致）
# ============================================================================

# 1. MOIGWODA优化
def moigwoda_optimize_weights(imf_predictions, true_values):
    """MOIGWODA优化（双目标：MAE + Std）"""
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    def objectives(weights):
        weights = np.clip(weights, 1e-6, 1.5)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        residual = true_values - pred
        mae = np.mean(np.abs(residual))
        std_residual = np.std(residual)
        return mae, std_residual
    
    population = np.random.uniform(0.3, 1.5, size=(pop_size, n_imfs))
    fitness = np.array([objectives(ind) for ind in population])
    archive = []
    
    def is_dominated(obj1, obj2):
        obj1 = np.array(obj1)
        obj2 = np.array(obj2)
        return np.all(obj2 <= obj1) and np.any(obj2 < obj1)
    
    def update_archive(archive, new_obj, new_sol):
        for arch_obj, _ in archive:
            if is_dominated(new_obj, arch_obj):
                return archive
        archive = [(obj, sol) for obj, sol in archive if not is_dominated(obj, new_obj)]
        archive.append((new_obj, new_sol.copy()))
        if len(archive) > OPT_ARCHIVE_SIZE:
            archive = archive[:OPT_ARCHIVE_SIZE]
        return archive
    
    for i in range(pop_size):
        archive = update_archive(archive, fitness[i], population[i])
    
    for iteration in range(max_iter):
        a = 2 - 2 * (iteration / max_iter) ** 2
        archive_sorted = sorted(archive, key=lambda x: x[0][0] + x[0][1])
        alpha = archive_sorted[0][1] if len(archive_sorted) > 0 else population[0]
        beta = archive_sorted[1][1] if len(archive_sorted) > 1 else population[1]
        delta = archive_sorted[2][1] if len(archive_sorted) > 2 else population[2]
        
        for i in range(pop_size):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_alpha = np.abs(C * alpha - population[i])
            X1 = alpha - A * D_alpha
            
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_beta = np.abs(C * beta - population[i])
            X2 = beta - A * D_beta
            
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_delta = np.abs(C * delta - population[i])
            X3 = delta - A * D_delta
            
            population[i] = (X1 + X2 + X3) / 3
            if np.random.rand() < 0.1:
                levy = np.random.standard_cauchy(n_imfs) * 0.01
                population[i] += levy
            population[i] = np.clip(population[i], 1e-6, 1.5)
            
            new_fitness = objectives(population[i])
            fitness[i] = new_fitness
            archive = update_archive(archive, new_fitness, population[i])
    
    best_solution = min(archive, key=lambda x: x[0][0] + x[0][1])
    optimal_weights = best_solution[1]
    best_objectives = best_solution[0]
    
    return optimal_weights, best_objectives[0]


# 2. PSO优化
def pso_optimize_weights(imf_predictions, true_values):
    """PSO优化"""
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    def objective(weights):
        weights = np.clip(weights, 1e-6, 1.5)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        residual = true_values - pred
        mae = np.mean(np.abs(residual))
        std = np.std(residual)
        return mae + std
    
    particles = np.random.uniform(0.3, 1.5, size=(pop_size, n_imfs))
    velocities = np.random.uniform(-0.1, 0.1, size=(pop_size, n_imfs))
    pbest = particles.copy()
    pbest_fitness = np.array([objective(p) for p in particles])
    gbest_idx = np.argmin(pbest_fitness)
    gbest = pbest[gbest_idx].copy()
    gbest_fitness = pbest_fitness[gbest_idx]
    
    w, c1, c2 = 0.7, 1.5, 1.5
    
    for iteration in range(max_iter):
        for i in range(pop_size):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (pbest[i] - particles[i]) +
                           c2 * r2 * (gbest - particles[i]))
            particles[i] = particles[i] + velocities[i]
            particles[i] = np.clip(particles[i], 1e-6, 1.5)
            
            fitness = objective(particles[i])
            if fitness < pbest_fitness[i]:
                pbest[i] = particles[i].copy()
                pbest_fitness[i] = fitness
                if fitness < gbest_fitness:
                    gbest = particles[i].copy()
                    gbest_fitness = fitness
    
    pred_best = sum(w * p for w, p in zip(gbest, imf_predictions))
    residual_best = true_values - pred_best
    mae_best = np.mean(np.abs(residual_best))
    
    return gbest, mae_best


# 3. NSGA-2优化（简化版）
def nsga2_optimize_weights(imf_predictions, true_values):
    """NSGA-2优化"""
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    def objectives(weights):
        weights = np.clip(weights, 1e-6, 1.5)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        residual = true_values - pred
        mae = np.mean(np.abs(residual))
        std_residual = np.std(residual)
        return mae, std_residual
    
    population = [np.random.uniform(0.3, 1.5, n_imfs) for _ in range(pop_size)]
    
    for iteration in range(max_iter):
        fitness_values = [objectives(ind) for ind in population]
        offspring = []
        for ind in population:
            if np.random.rand() < 0.9:
                mutant = ind + np.random.normal(0, 0.1, n_imfs)
                mutant = np.clip(mutant, 1e-6, 1.5)
                offspring.append(mutant)
        
        combined = population + offspring
        combined_fitness = [objectives(ind) for ind in combined]
        
        # 简单选择：按MAE+Std排序
        sorted_indices = sorted(range(len(combined)), 
                              key=lambda i: combined_fitness[i][0] + combined_fitness[i][1])
        population = [combined[i].copy() for i in sorted_indices[:pop_size]]
    
    fitness_values = [objectives(ind) for ind in population]
    best_idx = min(range(len(fitness_values)), 
                   key=lambda i: fitness_values[i][0] + fitness_values[i][1])
    optimal_weights = population[best_idx]
    best_objectives = fitness_values[best_idx]
    
    return optimal_weights, best_objectives[0]


# 4. DE优化（差分进化）
def de_optimize_weights(imf_predictions, true_values):
    """差分进化优化"""
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    F, CR = 0.8, 0.9
    
    def objective(weights):
        weights = np.clip(weights, 1e-6, 1.5)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        mae = np.mean(np.abs(true_values - pred))
        return mae
    
    population = np.random.uniform(0.3, 1.5, size=(pop_size, n_imfs))
    fitness = np.array([objective(ind) for ind in population])
    
    for iteration in range(max_iter):
        for i in range(pop_size):
            indices = [idx for idx in range(pop_size) if idx != i]
            a, b, c = population[np.random.choice(indices, 3, replace=False)]
            mutant = a + F * (b - c)
            mutant = np.clip(mutant, 1e-6, 1.5)
            
            cross_points = np.random.rand(n_imfs) < CR
            if not np.any(cross_points):
                cross_points[np.random.randint(0, n_imfs)] = True
            trial = np.where(cross_points, mutant, population[i])
            
            trial_fitness = objective(trial)
            if trial_fitness < fitness[i]:
                population[i] = trial
                fitness[i] = trial_fitness
    
    best_idx = np.argmin(fitness)
    return population[best_idx], fitness[best_idx]


# 5. ABC优化（人工蜂群）
def abc_optimize_weights(imf_predictions, true_values):
    """人工蜂群优化"""
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE // 2
    max_iter = OPT_MAX_ITER
    limit = 20
    
    def objective(weights):
        weights = np.clip(weights, 1e-6, 1.5)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        mae = np.mean(np.abs(true_values - pred))
        return mae
    
    food_sources = np.random.uniform(0.3, 1.5, size=(pop_size, n_imfs))
    fitness = np.array([1.0 / (1.0 + objective(f)) for f in food_sources])
    trial = np.zeros(pop_size)
    
    for iteration in range(max_iter):
        # 雇佣蜂
        for i in range(pop_size):
            k = np.random.choice([j for j in range(pop_size) if j != i])
            phi = np.random.uniform(-1, 1, n_imfs)
            new_solution = food_sources[i] + phi * (food_sources[i] - food_sources[k])
            new_solution = np.clip(new_solution, 1e-6, 1.5)
            
            new_fitness = 1.0 / (1.0 + objective(new_solution))
            if new_fitness > fitness[i]:
                food_sources[i] = new_solution
                fitness[i] = new_fitness
                trial[i] = 0
            else:
                trial[i] += 1
        
        # 观察蜂
        prob = fitness / fitness.sum()
        for i in range(pop_size):
            if np.random.rand() < prob[i]:
                k = np.random.choice([j for j in range(pop_size) if j != i])
                phi = np.random.uniform(-1, 1, n_imfs)
                new_solution = food_sources[i] + phi * (food_sources[i] - food_sources[k])
                new_solution = np.clip(new_solution, 1e-6, 1.5)
                
                new_fitness = 1.0 / (1.0 + objective(new_solution))
                if new_fitness > fitness[i]:
                    food_sources[i] = new_solution
                    fitness[i] = new_fitness
                    trial[i] = 0
        
        # 侦查蜂
        for i in range(pop_size):
            if trial[i] > limit:
                food_sources[i] = np.random.uniform(0.3, 1.5, n_imfs)
                fitness[i] = 1.0 / (1.0 + objective(food_sources[i]))
                trial[i] = 0
    
    best_idx = np.argmax(fitness)
    best_mae = objective(food_sources[best_idx])
    return food_sources[best_idx], best_mae

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("使用设备:", DEVICE)
    print("="*80)
    print("✅ 消融实验：2015-2025扩展版（无数据泄漏版本）")
    print("="*80)
    
    # 1. 加载数据
    print(f"\n步骤1: 加载数据")
    df = pd.read_excel(DATA_PATH, sheet_name='close')
    
    if STOCK_NAME not in df.columns:
        print(f"错误：找不到股票 {STOCK_NAME}")
        return
    
    # 转换为长格式（与原始实验脚本完全一致）
    data = pd.DataFrame({
        'date': pd.to_datetime(df.iloc[:, 0]),  # ✅ 使用iloc获取第一列作为日期
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    data = data.sort_values('date').reset_index(drop=True)
    
    print(f"  股票代码: {STOCK_NAME}")
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本数: {len(data)}")
    
    # 2. 分割数据
    train_size = int(len(data) * TRAIN_RATIO)
    train_data = data.iloc[:train_size]
    test_data = data.iloc[train_size:]
    
    print(f"\n步骤2: 分割数据（train:test = {TRAIN_RATIO}:{1-TRAIN_RATIO}）")
    print(f"  训练集: {train_data['date'].min()} ~ {train_data['date'].max()} ({len(train_data)})")
    print(f"  测试集: {test_data['date'].min()} ~ {test_data['date'].max()} ({len(test_data)})")
    
    # 3. CEEMDAN分解
    print(f"\n步骤3: CEEMDAN分解")
    full_prices = data['close'].values
    ceemdan = CEEMDAN()
    imfs = ceemdan(full_prices)
    n_imfs = len(imfs)
    print(f"  ✓ 分解完成: {n_imfs}个IMF")
    
    # 4. 训练各个IMF（使用无泄漏版本）
    print(f"\n步骤4: ReliefF特征选择 + CNN-BiLSTM-GRU训练（✅ 无数据泄漏）")
    
    imf_test_predictions = []
    
    for i in range(n_imfs):
        print(f"\n  --- IMF{i+1} ReliefF特征选择 ---")
        selected_lags = relieff_feature_selection(
            imfs[i], max_lag=MAX_LAG, n_features_to_select=N_FEATURES_TO_SELECT
        )
        
        print(f"\n{'='*60}")
        print(f"IMF {i+1} 训练（✅ 无数据泄漏）")
        print(f"{'='*60}")
        
        train_pred, test_pred = train_single_imf_no_leakage(
            imfs[i], train_size, selected_lags, i
        )
        
        imf_test_predictions.append(test_pred)
    
    # 5. 对齐预测长度
    print(f"\n步骤5: 对齐预测长度")
    min_test_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions_aligned = [p[-min_test_len:] for p in imf_test_predictions]
    
    test_true = test_data['close'].values[-min_test_len:]
    test_dates = test_data['date'].values[-min_test_len:]
    
    print(f"  对齐后测试预测长度: {min_test_len}")
    
    # 🔍 调试：打印每个IMF的预测统计
    print(f"\n🔍 调试：各IMF预测值统计")
    for i, pred in enumerate(imf_test_predictions_aligned):
        print(f"  IMF{i+1}: mean={np.mean(pred):.4f}, std={np.std(pred):.4f}, range=[{np.min(pred):.4f}, {np.max(pred):.4f}]")
    print(f"  真实值: mean={np.mean(test_true):.4f}, std={np.std(test_true):.4f}, range=[{np.min(test_true):.4f}, {np.max(test_true):.4f}]")
    print(f"  直接求和预测: mean={np.mean(np.sum(imf_test_predictions_aligned, axis=0)):.4f}")
    
    # 6. 消融实验
    results = {}
    
    # 直接求和
    print(f"\n{'='*80}")
    print("方法1: 直接求和（基线）")
    print(f"{'='*80}")
    test_pred_sum = np.sum(imf_test_predictions_aligned, axis=0)
    mae_sum = mean_absolute_error(test_true, test_pred_sum)
    rmse_sum = np.sqrt(mean_squared_error(test_true, test_pred_sum))
    r2_sum = r2_score(test_true, test_pred_sum)
    print(f"  MAE={mae_sum:.4f}, RMSE={rmse_sum:.4f}, R²={r2_sum:.4f}")
    results['直接求和'] = {'pred': test_pred_sum, 'mae': mae_sum, 'rmse': rmse_sum, 'r2': r2_sum}
    
    # 优化算法
    optimizers = {
        'MOIGWODA': moigwoda_optimize_weights,
        'PSO': pso_optimize_weights,
        'NSGA-2': nsga2_optimize_weights,
        'DE': de_optimize_weights,
        'ABC': abc_optimize_weights
    }
    
    for opt_name, opt_func in optimizers.items():
        print(f"\n{'='*80}")
        print(f"{opt_name} 优化")
        print(f"{'='*80}")
        try:
            weights, mae_opt = opt_func(imf_test_predictions_aligned, test_true)
            print(f"  🔍 优化权重: {[f'{w:.4f}' for w in weights]}")
            test_pred = sum(w * p for w, p in zip(weights, imf_test_predictions_aligned))
            print(f"  🔍 预测值范围: [{np.min(test_pred):.4f}, {np.max(test_pred):.4f}], 均值: {np.mean(test_pred):.4f}")
            rmse_opt = np.sqrt(mean_squared_error(test_true, test_pred))
            r2_opt = r2_score(test_true, test_pred)
            print(f"  MAE={mae_opt:.4f}, RMSE={rmse_opt:.4f}, R²={r2_opt:.4f}")
            results[opt_name] = {'pred': test_pred, 'weights': weights, 'mae': mae_opt, 'rmse': rmse_opt, 'r2': r2_opt}
        except Exception as e:
            print(f"  ✗ {opt_name} 失败: {e}")
    
    # 7. 结果对比（包含Naive baseline）
    print(f"\n{'='*80}")
    print("消融实验结果对比（含Naive Baseline）")
    print(f"{'='*80}")
    
    # 计算Naive baseline
    naive_pred = test_true[:-1]
    naive_true = test_true[1:]
    naive_mae = mean_absolute_error(naive_true, naive_pred)
    naive_rmse = np.sqrt(mean_squared_error(naive_true, naive_pred))
    naive_r2 = r2_score(naive_true, naive_pred)
    
    print(f"\n{'方法':<20} {'MAE':<12} {'RMSE':<12} {'R²':<12} {'vs Naive':<15}")
    print("-" * 75)
    print(f"{'Naive (t=t-1)':<20} {naive_mae:<12.4f} {naive_rmse:<12.4f} {naive_r2:<12.4f} {'基准':<15}")
    print("-" * 75)
    
    for method_name, res in results.items():
        improvement = (naive_mae - res['mae']) / naive_mae * 100
        imp_str = f"+{improvement:.1f}%" if improvement > 0 else f"{improvement:.1f}%"
        print(f"{method_name:<20} {res['mae']:<12.4f} {res['rmse']:<12.4f} {res['r2']:<12.4f} {imp_str:<15}")
    
    best_method = min(results.keys(), key=lambda k: results[k]['mae'])
    print(f"\n🏆 最优方法: {best_method} (MAE={results[best_method]['mae']:.4f})")
    best_improvement = (naive_mae - results[best_method]['mae']) / naive_mae * 100
    print(f"   相对Naive改进: {best_improvement:+.2f}%")
    
    # 7. 可视化
    print(f"\n步骤6: 生成可视化")
    
    n_methods = len(results)
    n_cols = 3
    n_rows = (n_methods + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 6*n_rows))
    if n_rows == 1:
        axes = axes.reshape(1, -1)
    axes = axes.flatten()
    
    for idx, (method_name, res) in enumerate(results.items()):
        ax = axes[idx]
        ax.plot(test_dates, test_true, label='Actual Price', color='blue', 
                linewidth=2, marker='o', markersize=2)
        ax.plot(test_dates, res['pred'], label='Predicted Price', color='red', 
                linewidth=2, marker='s', markersize=2, alpha=0.7)
        
        ax.set_xlabel('Date', fontsize=10)
        ax.set_ylabel('Price (USD)', fontsize=10)
        ax.set_title(f'{method_name} (No Leakage)\nMAE={res["mae"]:.2f}, RMSE={res["rmse"]:.2f}, R2={res["r2"]:.4f}',
                     fontsize=12)
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='x', rotation=45)
    
    # 隐藏多余的子图
    for idx in range(n_methods, len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    output_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_2015_no_leakage_comparison.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"  ✓ 已保存: {output_path}")
    plt.close()
    
    # 8. 保存结果
    results_df = pd.DataFrame({
        'date': test_dates,
        'actual': test_true
    })
    
    for method_name, res in results.items():
        results_df[f'pred_{method_name.lower().replace(" ", "_").replace("-", "_")}'] = res['pred']
    
    results_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp2_weight15_no_leakage_results.csv')
    results_df.to_csv(results_path, index=False)
    print(f"\n  ✓ 结果已保存: {results_path}")
    
    print(f"\n{'='*80}")
    print("✅ 无数据泄漏版本实验完成！")
    print(f"{'='*80}")

if __name__ == '__main__':
    import sys
    try:
        main()
        sys.exit(0)  # 成功
    except Exception as e:
        print(f"\n❌ 实验失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)  # 失败
