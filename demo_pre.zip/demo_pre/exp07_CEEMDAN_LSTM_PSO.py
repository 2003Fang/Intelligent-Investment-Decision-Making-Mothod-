"""
实验7: CEEMDAN-ReliefF-LSTM-PSO
"""

import sys
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import copy
import warnings
warnings.filterwarnings('ignore')

from common_config import *
from common_utils import *

# 修复PyEMD导入（必须导入class而非module）
from PyEMD.EMD import EMD
import PyEMD
PyEMD.EMD = EMD  # Monkey patch修复内部导入
from PyEMD.CEEMDAN import CEEMDAN

class SimpleLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=64, dense_units=32, dropout=0.3):
        super(SimpleLSTM, self).__init__()
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        h_n = h_n[-1]
        h_n = self.dropout1(h_n)
        x = self.fc1(h_n)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        return x.squeeze()

def train_single_imf(imf_train, imf_test, selected_lags):
    # 标准化（只用训练集fit）
    train_scaled, test_scaled, scaler = normalize_data(imf_train, imf_test)
    
    # 拼接完整序列后创建滞后特征（与BASE_AttLSTM.py一致）
    imf_scaled = np.concatenate([train_scaled, test_scaled])
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_size = len(imf_train)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    train_dataset = StockDataset(X_train, y_train)
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    model = SimpleLSTM(
        input_dim=len(selected_lags),
        lstm_units=LSTM_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10
    )
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if patience_counter >= PATIENCE:
            break
    
    if best_state is not None:
        model.load_state_dict(best_state)
    
    model.eval()
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    test_pred = scaler.inverse_transform(
        np.array(test_pred_scaled).reshape(-1, 1)
    ).flatten()
    
    return test_pred

def pso_optimize_weights(imf_predictions, true_values):
    n_imfs = len(imf_predictions)
    
    def objective(weights):
        weights = clip_weights(weights)
        pred = sum(w * p for w, p in zip(weights, imf_predictions))
        mae = np.mean(np.abs(true_values - pred))
        return mae
    
    particles = []
    velocities = []
    for _ in range(PSO_POP_SIZE):
        particle = np.random.uniform(0.3, 1.5, n_imfs)
        particles.append(clip_weights(particle))
        velocities.append(np.random.uniform(-0.1, 0.1, n_imfs))
    
    particles = np.array(particles)
    velocities = np.array(velocities)
    
    pbest = particles.copy()
    pbest_scores = np.array([objective(p) for p in particles])
    
    gbest_idx = np.argmin(pbest_scores)
    gbest = pbest[gbest_idx].copy()
    gbest_score = pbest_scores[gbest_idx]
    
    w = 0.7
    c1 = 1.5
    c2 = 1.5
    
    for iteration in range(PSO_MAX_ITER):
        for i in range(PSO_POP_SIZE):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (pbest[i] - particles[i]) +
                           c2 * r2 * (gbest - particles[i]))
            
            particles[i] = particles[i] + velocities[i]
            particles[i] = clip_weights(particles[i])
            
            score = objective(particles[i])
            
            if score < pbest_scores[i]:
                pbest[i] = particles[i].copy()
                pbest_scores[i] = score
                
                if score < gbest_score:
                    gbest = particles[i].copy()
                    gbest_score = score
    
    optimal_weights = clip_weights(gbest)
    return optimal_weights

def train_and_predict_ceemdan_lstm_pso(stock_key):
    print(f"\n{'='*80}")
    print(f"股票: {stock_key}")
    print(f"{'='*80}")
    
    dataset_name, stock_name = STOCK_DATASETS[stock_key]
    data_path = get_stock_data_path(dataset_name)
    df = load_stock_data(data_path, dataset_name, stock_name)
    
    train_df, test_df = split_train_test(df, TRAIN_RATIO)
    prices = df['close'].values
    train_size = len(train_df)
    
    print(f"训练集: {len(train_df)} 样本")
    print(f"测试集: {len(test_df)} 样本")
    
    print("CEEMDAN分解中...")
    ceemdan = CEEMDAN()
    imfs = ceemdan(prices)  # 对整个序列分解（训练+测试）
    n_imfs = len(imfs)
    print(f"分解完成: {n_imfs}个IMF分量")
    
    print("训练各IMF...")
    imf_test_predictions = []
    
    for i in range(n_imfs):
        print(f"\nIMF{i+1}/{n_imfs}")
        # 切分IMF为训练/测试集
        imf_train = imfs[i][:train_size]
        imf_test = imfs[i][train_size:]
        
        # ReliefF特征选择（只在训练集上）
        selected_lags = relieff_feature_selection(
            imf_train, MAX_LAG, N_FEATURES_TO_SELECT
        )
        print(f"  选择的滞后项: {selected_lags}")
        
        # 训练并预测（现在imf_test长度正确）
        test_pred = train_single_imf(imf_train, imf_test, selected_lags)
        imf_test_predictions.append(test_pred)
    
    min_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions = [p[-min_len:] for p in imf_test_predictions]
    test_true = test_df['close'].values[-min_len:]
    test_dates = test_df['date'].values[-min_len:]
    
    print(f"\nPSO优化权重...")
    optimal_weights = pso_optimize_weights(imf_test_predictions, test_true)
    print(f"最优权重: {optimal_weights}")
    
    predictions = sum(w * p for w, p in zip(optimal_weights, imf_test_predictions))
    
    metrics = calculate_metrics(test_true, predictions)
    print_metrics(metrics, "  ")
    
    output_prefix = get_output_prefix('exp07_CEEMDAN_LSTM_PSO', stock_key)
    
    save_predictions(
        test_dates, test_true, predictions,
        os.path.join(OUTPUT_DIR, 'predictions', f'{output_prefix}.csv')
    )
    
    save_metrics(
        metrics, 'exp07_CEEMDAN_LSTM_PSO', stock_key,
        os.path.join(OUTPUT_DIR, 'metrics', 'all_metrics.csv')
    )
    
    plot_predictions(
        test_dates, test_true, predictions,
        f'CEEMDAN-LSTM-PSO - {get_stock_name(stock_key)}',
        os.path.join(OUTPUT_DIR, 'figures', f'{output_prefix}.png')
    )
    
    print(f"完成!")
    return metrics

def main():
    print("="*80)
    print("实验7: CEEMDAN-LSTM-PSO")
    print("="*80)
    
    all_results = {}
    
    for stock_key in ALL_STOCK_KEYS:
        try:
            metrics = train_and_predict_ceemdan_lstm_pso(stock_key)
            all_results[stock_key] = metrics
        except Exception as e:
            print(f"错误: {stock_key} 失败 - {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n{'='*80}")
    print(f"实验7完成! 成功: {len(all_results)}/{len(ALL_STOCK_KEYS)}")
    print(f"{'='*80}")

if __name__ == '__main__':
    main()
