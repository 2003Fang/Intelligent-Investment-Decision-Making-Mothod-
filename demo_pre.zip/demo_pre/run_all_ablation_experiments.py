"""
消融实验完整工作流
自动运行所有4个消融实验，并生成对比表格和可视化

实验设计:
- exp1: Full Model (CEEMDAN + ReliefF + AttLSTM + PSO) - Baseline
- exp2: Ablation-1 (去掉CEEMDAN)
- exp3: Ablation-2 (去掉ReliefF)
- exp4: Ablation-3 (去掉PSO优化，用直接求和)
"""

import os
import sys
import subprocess
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\消融实验\result'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 实验配置
# ============================================================================

EXPERIMENTS = {
    'exp1': {
        'name': 'Full Model',
        'description': 'CEEMDAN + ReliefF + AttLSTM + PSO',
        'script': 'exp1_full_BASE_AttLSTM.py',
        'metrics_file': None,  # Full model从BASE_AttLSTM.py生成的结果中获取
        'color': '#2E86AB'
    },
    'exp2': {
        'name': 'Ablation-1',
        'description': '去掉CEEMDAN (ReliefF + AttLSTM + PSO)',
        'script': 'exp2_ablation1_no_CEEMDAN.py',
        'metrics_file': 'exp2_ablation1_metrics.csv',
        'color': '#A23B72'
    },
    'exp3': {
        'name': 'Ablation-2',
        'description': '去掉ReliefF (CEEMDAN + AttLSTM + PSO)',
        'script': 'exp3_ablation2_no_ReliefF.py',
        'metrics_file': 'exp3_ablation2_metrics.csv',
        'color': '#F18F01'
    },
    'exp4': {
        'name': 'Ablation-3',
        'description': '去掉PSO (CEEMDAN + ReliefF + AttLSTM + 直接求和)',
        'script': 'exp4_ablation3_no_PSO.py',
        'metrics_file': 'exp4_ablation3_metrics.csv',
        'color': '#C73E1D'
    }
}

# ============================================================================
# 运行实验
# ============================================================================

def run_experiment(exp_id, exp_config):
    """运行单个实验"""
    print("\n" + "="*80)
    print(f"运行 {exp_config['name']}: {exp_config['description']}")
    print("="*80)
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    script_path = exp_config['script']
    
    if not os.path.exists(script_path):
        print(f"❌ 错误: 找不到脚本 {script_path}")
        return False
    
    try:
        # 运行实验
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        # 输出日志
        print(result.stdout)
        
        if result.returncode != 0:
            print(f"❌ {exp_config['name']} 失败!")
            print(result.stderr)
            return False
        else:
            print(f"✅ {exp_config['name']} 完成!")
            print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            return True
            
    except Exception as e:
        print(f"❌ {exp_config['name']} 异常: {e}")
        return False

# ============================================================================
# 收集结果
# ============================================================================

def collect_results():
    """收集所有实验的评估指标"""
    print("\n" + "="*80)
    print("收集实验结果")
    print("="*80)
    
    all_metrics = []
    
    for exp_id, exp_config in EXPERIMENTS.items():
        metrics_file = exp_config['metrics_file']
        
        if metrics_file is None:
            # exp1的结果需要从BASE_AttLSTM.py的输出中获取
            # 暂时跳过，需要手动添加
            print(f"⚠️  {exp_config['name']}: 需要手动提供指标")
            continue
        
        metrics_path = os.path.join(OUTPUT_DIR, metrics_file)
        
        if os.path.exists(metrics_path):
            df = pd.read_csv(metrics_path)
            df['exp_id'] = exp_id
            df['exp_name'] = exp_config['name']
            df['description'] = exp_config['description']
            all_metrics.append(df)
            print(f"✓ {exp_config['name']}: 已加载")
        else:
            print(f"✗ {exp_config['name']}: 找不到结果文件 {metrics_path}")
    
    if len(all_metrics) == 0:
        print("❌ 没有找到任何结果文件!")
        return None
    
    # 合并所有结果
    results_df = pd.concat(all_metrics, ignore_index=True)
    
    # 保存汇总结果
    summary_path = os.path.join(OUTPUT_DIR, 'ablation_summary.csv')
    results_df.to_csv(summary_path, index=False, encoding='utf-8-sig')
    print(f"\n✓ 汇总结果已保存: {summary_path}")
    
    return results_df

# ============================================================================
# 生成对比表格
# ============================================================================

def generate_comparison_table(results_df):
    """生成对比表格"""
    print("\n" + "="*80)
    print("生成对比表格")
    print("="*80)
    
    # 选择关键指标
    metrics_cols = ['MAE', 'RMSE', 'R2', 'MAPE', 'DA', 'TIC']
    
    # 创建对比表
    comparison = results_df[['exp_name', 'description'] + metrics_cols].copy()
    
    # 格式化数值
    for col in metrics_cols:
        if col in ['MAPE', 'DA']:
            comparison[col] = comparison[col].apply(lambda x: f"{x:.2f}%")
        else:
            comparison[col] = comparison[col].apply(lambda x: f"{x:.4f}")
    
    # 保存为CSV
    csv_path = os.path.join(OUTPUT_DIR, 'ablation_comparison_table.csv')
    comparison.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"✓ 对比表已保存: {csv_path}")
    
    # 保存为Excel（更美观）
    excel_path = os.path.join(OUTPUT_DIR, 'ablation_comparison_table.xlsx')
    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        comparison.to_excel(writer, sheet_name='消融实验对比', index=False)
    print(f"✓ Excel表已保存: {excel_path}")
    
    # 打印表格
    print("\n消融实验对比表:")
    print("="*80)
    print(comparison.to_string(index=False))
    print("="*80)

# ============================================================================
# 生成可视化
# ============================================================================

def generate_visualizations(results_df):
    """生成可视化对比图"""
    print("\n" + "="*80)
    print("生成可视化图表")
    print("="*80)
    
    # 1. 六个指标的对比柱状图
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    fig.suptitle('消融实验评估指标对比', fontsize=16, fontweight='bold')
    
    metrics = ['MAE', 'RMSE', 'R2', 'MAPE', 'DA', 'TIC']
    metric_names = {
        'MAE': 'MAE (Mean Absolute Error)',
        'RMSE': 'RMSE (Root Mean Squared Error)',
        'R2': 'R² (Coefficient of Determination)',
        'MAPE': 'MAPE (%) (Mean Absolute Percentage Error)',
        'DA': 'DA (%) (Direction Accuracy)',
        'TIC': 'TIC (Theil Inequality Coefficient)'
    }
    
    # 获取颜色
    colors = [EXPERIMENTS[exp_id]['color'] for exp_id in results_df['exp_id']]
    
    for idx, metric in enumerate(metrics):
        ax = axes[idx // 3, idx % 3]
        
        values = results_df[metric].values
        names = results_df['exp_name'].values
        
        bars = ax.bar(range(len(values)), values, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)
        
        ax.set_xlabel('实验', fontsize=11, fontweight='bold')
        ax.set_ylabel(metric_names[metric], fontsize=11, fontweight='bold')
        ax.set_title(metric_names[metric], fontsize=12, fontweight='bold')
        ax.set_xticks(range(len(values)))
        ax.set_xticklabels(names, rotation=15, ha='right')
        ax.grid(axis='y', alpha=0.3, linestyle='--')
        
        # 在柱子上标注数值
        for bar, value in zip(bars, values):
            height = bar.get_height()
            if metric in ['MAPE', 'DA']:
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{value:.2f}%', ha='center', va='bottom', fontsize=9, fontweight='bold')
            else:
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{value:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    plt.tight_layout()
    
    # 保存图表
    fig_path = os.path.join(OUTPUT_DIR, 'ablation_comparison_metrics.png')
    plt.savefig(fig_path, dpi=300, bbox_inches='tight')
    print(f"✓ 对比图已保存: {fig_path}")
    plt.close()
    
    # 2. 雷达图（展示综合性能）
    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
    
    # 归一化指标（使所有指标都是"越大越好"）
    metrics_radar = ['MAE', 'RMSE', 'R2', 'MAPE', 'TIC']
    normalized_data = []
    
    for _, row in results_df.iterrows():
        values = []
        # MAE: 越小越好 -> 归一化为 1 - (value / max_value)
        mae_norm = 1 - (row['MAE'] / results_df['MAE'].max())
        values.append(mae_norm)
        
        # RMSE: 越小越好
        rmse_norm = 1 - (row['RMSE'] / results_df['RMSE'].max())
        values.append(rmse_norm)
        
        # R2: 越大越好 -> 直接使用
        values.append(row['R2'])
        
        # MAPE: 越小越好
        mape_norm = 1 - (row['MAPE'] / results_df['MAPE'].max())
        values.append(mape_norm)
        
        # TIC: 越小越好
        tic_norm = 1 - (row['TIC'] / results_df['TIC'].max())
        values.append(tic_norm)
        
        normalized_data.append(values)
    
    # 绘制雷达图
    angles = np.linspace(0, 2 * np.pi, len(metrics_radar), endpoint=False).tolist()
    angles += angles[:1]  # 闭合
    
    for idx, (_, row) in enumerate(results_df.iterrows()):
        values = normalized_data[idx]
        values += values[:1]  # 闭合
        
        color = EXPERIMENTS[row['exp_id']]['color']
        ax.plot(angles, values, 'o-', linewidth=2, label=row['exp_name'], color=color)
        ax.fill(angles, values, alpha=0.15, color=color)
    
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics_radar, fontsize=12, fontweight='bold')
    ax.set_ylim(0, 1)
    ax.set_title('消融实验综合性能对比 (雷达图)\n所有指标已归一化为"越大越好"', 
                 fontsize=14, fontweight='bold', pad=20)
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=10)
    ax.grid(True, linestyle='--', alpha=0.5)
    
    radar_path = os.path.join(OUTPUT_DIR, 'ablation_radar_chart.png')
    plt.savefig(radar_path, dpi=300, bbox_inches='tight')
    print(f"✓ 雷达图已保存: {radar_path}")
    plt.close()

# ============================================================================
# 主函数
# ============================================================================

def main():
    print("="*80)
    print("消融实验完整工作流")
    print("="*80)
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n实验配置:")
    for exp_id, config in EXPERIMENTS.items():
        print(f"  {exp_id}: {config['name']} - {config['description']}")
    
    # 询问是否运行所有实验
    print("\n" + "="*80)
    print("选项:")
    print("  1. 运行所有实验 (exp1-exp4)")
    print("  2. 只生成对比表和可视化（假设实验已运行）")
    print("="*80)
    
    choice = input("请选择 [1/2] (默认=1): ").strip() or "1"
    
    if choice == "1":
        # 运行所有实验
        print("\n开始运行所有实验...")
        results = {}
        
        for exp_id in ['exp1', 'exp2', 'exp3', 'exp4']:
            exp_config = EXPERIMENTS[exp_id]
            success = run_experiment(exp_id, exp_config)
            results[exp_id] = success
        
        # 总结
        print("\n" + "="*80)
        print("实验运行总结")
        print("="*80)
        for exp_id, success in results.items():
            status = "✓ 成功" if success else "✗ 失败"
            print(f"  {EXPERIMENTS[exp_id]['name']}: {status}")
    
    # 收集结果并生成对比
    print("\n" + "="*80)
    print("生成对比分析")
    print("="*80)
    
    results_df = collect_results()
    
    if results_df is not None and len(results_df) > 0:
        generate_comparison_table(results_df)
        generate_visualizations(results_df)
        
        print("\n" + "="*80)
        print("✅ 消融实验工作流完成!")
        print("="*80)
        print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\n生成的文件:")
        print(f"  - 汇总结果: {os.path.join(OUTPUT_DIR, 'ablation_summary.csv')}")
        print(f"  - 对比表CSV: {os.path.join(OUTPUT_DIR, 'ablation_comparison_table.csv')}")
        print(f"  - 对比表Excel: {os.path.join(OUTPUT_DIR, 'ablation_comparison_table.xlsx')}")
        print(f"  - 对比柱状图: {os.path.join(OUTPUT_DIR, 'ablation_comparison_metrics.png')}")
        print(f"  - 雷达图: {os.path.join(OUTPUT_DIR, 'ablation_radar_chart.png')}")
    else:
        print("\n❌ 无法生成对比分析，请检查实验结果文件")

if __name__ == '__main__':
    main()
