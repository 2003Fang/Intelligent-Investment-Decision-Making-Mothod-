"""
实验9: CEEMDAN-ReliefF-MultiHeadAttLSTM 标准对比实验

核心改进：
✅ 使用多头注意力机制（Multi-Head Attention）替换标准注意力
✅ 4个注意力头，每个头关注不同的时间模式
✅ 其他配置与exp4完全相同，便于公平对比

改进点：
1. ✅ 合理权重约束：0 < wi ≤ 1.5（基于CEEMDAN分解特性）
2. ✅ 三个多目标优化算法公平对比：MOIGWODA、NSGA-2、多目标PSO
3. ✅ 可视化（预测曲线）
4. ✅ 无数据泄漏
5. ✅ 直接求和基线（CEEMDAN理论：原始=ΣIMFs）

实验目标：验证多头注意力在IMF预测中的有效性
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import copy

# 修复中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 黑体
plt.rcParams['axes.unicode_minus'] = False    # 负号正常显示

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler

# 信号分解和特征选择
from PyEMD import CEEMDAN
from skrebate import ReliefF

# 评估指标
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ============================================================================
# 配置参数
# ============================================================================

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\portfolio\dataset\SP_original\SP_factor.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\11.28prediction\comparison\result'

DATA_START = '2015-07-01'
DATA_END = '2025-06-30'
TRAIN_RATIO = 0.9

MAX_LAG = 10
N_FEATURES_TO_SELECT = 6

# ✅ 多头注意力参数
NUM_HEADS = 4  # 4个注意力头

CNN_FILTERS = 64
BILSTM_UNITS = 128
GRU_UNITS = 64
DENSE_UNITS = 32
DROPOUT = 0.3
LR = 0.001
BATCH_SIZE = 32
EPOCHS = 200
PATIENCE = 20

# ✅ 多目标优化参数
OPT_POP_SIZE = 100
OPT_MAX_ITER = 100
OPT_ARCHIVE_SIZE = 150

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================================
# 数据集类
# ============================================================================

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============================================================================
# 模型定义：MultiHeadAttLSTM
# ============================================================================

class MultiHeadAttentionLayer(nn.Module):
    """
    多头注意力机制
    
    核心思想：
    - 将隐状态投影到多个子空间（多个头）
    - 每个头独立计算注意力权重
    - 拼接所有头的输出并融合
    
    优势：
    - 不同的头可以关注不同的时间模式
    - 增强模型的表达能力
    """
    def __init__(self, hidden_size, num_heads=4):
        super(MultiHeadAttentionLayer, self).__init__()
        assert hidden_size % num_heads == 0, "hidden_size必须能被num_heads整除"
        
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        
        # Query, Key, Value投影（每个头独立）
        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)
        
        # 输出投影
        self.out_proj = nn.Linear(hidden_size, hidden_size)
    
    def forward(self, lstm_output):
        """
        Args:
            lstm_output: (batch_size, seq_len, hidden_size) LSTM隐状态
        
        Returns:
            context_vector: (batch_size, hidden_size) 多头注意力加权的上下文向量
        """
        batch_size, seq_len, hidden_size = lstm_output.shape
        
        # 1. 投影到Q, K, V
        Q = self.query(lstm_output)  # (batch, seq_len, hidden_size)
        K = self.key(lstm_output)
        V = self.value(lstm_output)
        
        # 2. 分割成多个头
        # 从 (batch, seq_len, hidden_size) -> (batch, seq_len, num_heads, head_dim)
        # 再转置为 (batch, num_heads, seq_len, head_dim)
        Q = Q.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        
        # 3. 计算注意力分数（缩放点积注意力）
        # (batch, num_heads, seq_len, head_dim) @ (batch, num_heads, head_dim, seq_len)
        # -> (batch, num_heads, seq_len, seq_len)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / np.sqrt(self.head_dim)
        
        # 4. Softmax得到注意力权重
        attn_weights = torch.softmax(scores, dim=-1)  # (batch, num_heads, seq_len, seq_len)
        
        # 5. 加权求和Value
        # (batch, num_heads, seq_len, seq_len) @ (batch, num_heads, seq_len, head_dim)
        # -> (batch, num_heads, seq_len, head_dim)
        attn_output = torch.matmul(attn_weights, V)
        
        # 6. 拼接所有头
        # (batch, num_heads, seq_len, head_dim) -> (batch, seq_len, num_heads, head_dim)
        # -> (batch, seq_len, hidden_size)
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(batch_size, seq_len, hidden_size)
        
        # 7. 输出投影
        attn_output = self.out_proj(attn_output)  # (batch, seq_len, hidden_size)
        
        # 8. 全局池化得到上下文向量（取平均）
        context_vector = torch.mean(attn_output, dim=1)  # (batch, hidden_size)
        
        return context_vector

class MultiHeadAttLSTM(nn.Module):
    """
    多头注意力LSTM
    
    相比标准AttLSTM的改进：
    - 使用多头注意力替换单头注意力
    - 4个头分别关注不同的时间模式
    """
    def __init__(self, input_dim, lstm_units=128, dense_units=32, dropout=0.3, num_heads=4):
        super(MultiHeadAttLSTM, self).__init__()
        
        # LSTM层（与exp4相同）
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        
        # ✅ 多头注意力层（改进）
        self.attention = MultiHeadAttentionLayer(lstm_units, num_heads=num_heads)
        
        # 全连接层（与exp4相同）
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        # LSTM编码
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        
        # 多头注意力
        x = self.attention(x)
        
        # 全连接预测
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        
        return x.squeeze()

# ============================================================================
# 特征工程
# ============================================================================

def create_lagged_features(data, lags):
    """创建滞后特征"""
    max_lag = max(lags)
    n = len(data)
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    
    return X, y

def relieff_feature_selection(imf, max_lag=10, n_features_to_select=6):
    """ReliefF特征选择"""
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(imf, all_lags)
    
    relieff = ReliefF(n_features_to_select=n_features_to_select, n_neighbors=10)
    relieff.fit(X, y)
    
    selected_indices = relieff.top_features_[:n_features_to_select]
    selected_lags = [all_lags[i] for i in selected_indices]
    selected_lags.sort()
    
    return selected_lags

# ============================================================================
# 训练函数（无数据泄漏）
# ============================================================================

def train_single_imf_no_leakage(imf_full, train_size, selected_lags, imf_idx):
    """
    训练单个IMF（无数据泄漏）
    """
    print(f"  训练集大小: {train_size}, 测试集大小: {len(imf_full) - train_size}")
    print(f"  选择的滞后项: {selected_lags}")
    
    # 分割数据
    imf_train = imf_full[:train_size]
    imf_test = imf_full[train_size:]
    
    # 只用训练集fit scaler
    scaler = StandardScaler()
    imf_train_scaled = scaler.fit_transform(imf_train.reshape(-1, 1)).flatten()
    imf_test_scaled = scaler.transform(imf_test.reshape(-1, 1)).flatten()
    
    # 拼接完整序列
    imf_scaled = np.concatenate([imf_train_scaled, imf_test_scaled])
    
    # 创建滞后特征
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    
    # 分割训练集和测试集
    max_lag = max(selected_lags)
    train_end_idx = train_size - max_lag
    
    X_train = X_full[:train_end_idx]
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:]
    y_test = y_full[train_end_idx:]
    
    print(f"  训练样本数: {len(X_train)}, 测试样本数: {len(X_test)}")
    
    # 转换为3D
    X_train = X_train.reshape(-1, len(selected_lags), 1)
    X_test = X_test.reshape(-1, len(selected_lags), 1)
    
    # 数据加载器
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    val_size_split = len(train_dataset) - train_size_split
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, val_size_split]
    )
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_dataset = StockDataset(X_test, y_test)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # ✅ 多头注意力模型
    model = MultiHeadAttLSTM(
        input_dim=len(selected_lags),
        lstm_units=GRU_UNITS,
        dense_units=DENSE_UNITS,
        dropout=DROPOUT,
        num_heads=NUM_HEADS
    ).to(DEVICE)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', 
                                                      factor=0.5, patience=10)
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    print(f"  开始训练（最大{EPOCHS}个epoch，早停patience={PATIENCE}）...")
    print(f"  模型类型: MultiHeadAttLSTM ({NUM_HEADS}个注意力头)")
    
    for epoch in range(EPOCHS):
        # 训练
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
            optimizer.zero_grad()
            y_pred = model(X_batch)
            loss = criterion(y_pred, y_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # 验证
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                y_pred = model(X_batch)
                loss = criterion(y_pred, y_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"    Epoch {epoch+1:3d}/{EPOCHS}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}, patience={patience_counter}/{PATIENCE}")
        
        if patience_counter >= PATIENCE:
            print(f"  ✓ 早停触发: epoch {epoch+1}")
            break
    
    # 加载最佳模型
    if best_state is not None:
        model.load_state_dict(best_state)
    
    # 预测
    model.eval()
    train_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=False):
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            train_pred_scaled.extend(pred)
    
    test_pred_scaled = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(DEVICE)
            pred = model(X_batch).cpu().numpy()
            test_pred_scaled.extend(pred)
    
    # 反标准化
    train_pred = scaler.inverse_transform(np.array(train_pred_scaled).reshape(-1, 1)).flatten()
    test_pred = scaler.inverse_transform(np.array(test_pred_scaled).reshape(-1, 1)).flatten()
    
    print(f"  ✓ IMF{imf_idx+1} 预测完成")
    
    return train_pred, test_pred

# ============================================================================
# ✅ 多目标优化算法（与exp4相同）
# ============================================================================

def clip_weights(weights, w_min=1e-6, w_max=1.5):
    """限制权重在合理范围内（基于CEEMDAN：基线=1.0）"""
    weights = np.clip(weights, w_min, w_max)
    return weights

def compute_objectives(weights, imf_predictions, true_values):
    """计算两个目标：MAE和Std"""
    weights = clip_weights(weights)
    pred = sum(w * p for w, p in zip(weights, imf_predictions))
    residual = true_values - pred
    mae = np.mean(np.abs(residual))
    std_residual = np.std(residual)
    return mae, std_residual

# 1. MOIGWODA多目标优化
def moigwoda_optimize_weights(imf_predictions, true_values):
    """MOIGWODA多目标优化"""
    print("  🔄 MOIGWODA优化中...")
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    population = np.random.uniform(0.3, 1.5, size=(pop_size, n_imfs))
    fitness = np.array([compute_objectives(ind, imf_predictions, true_values) for ind in population])
    archive = []
    
    def is_dominated(obj1, obj2):
        obj1 = np.array(obj1)
        obj2 = np.array(obj2)
        return np.all(obj2 <= obj1) and np.any(obj2 < obj1)
    
    def update_archive(archive, new_obj, new_sol):
        for arch_obj, _ in archive:
            if is_dominated(new_obj, arch_obj):
                return archive
        archive = [(obj, sol) for obj, sol in archive if not is_dominated(obj, new_obj)]
        archive.append((new_obj, new_sol.copy()))
        if len(archive) > OPT_ARCHIVE_SIZE:
            archive = sorted(archive, key=lambda x: x[0][0] + x[0][1])[:OPT_ARCHIVE_SIZE]
        return archive
    
    for i in range(pop_size):
        archive = update_archive(archive, fitness[i], population[i])
    
    for iteration in range(max_iter):
        a = 2 * (0.5 ** (iteration / max_iter))
        archive_sorted = sorted(archive, key=lambda x: x[0][0] + x[0][1])
        alpha = archive_sorted[0][1] if len(archive_sorted) > 0 else population[0]
        beta = archive_sorted[1][1] if len(archive_sorted) > 1 else population[1]
        delta = archive_sorted[2][1] if len(archive_sorted) > 2 else population[2]
        
        for i in range(pop_size):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_alpha = np.abs(C * alpha - population[i])
            X1 = alpha - A * D_alpha
            
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_beta = np.abs(C * beta - population[i])
            X2 = beta - A * D_beta
            
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            A = 2 * a * r1 - a
            C = 2 * r2
            D_delta = np.abs(C * delta - population[i])
            X3 = delta - A * D_delta
            
            population[i] = (X1 + X2 + X3) / 3
            if np.random.rand() < 0.1:
                levy = np.random.standard_cauchy(n_imfs) * 0.01
                population[i] += levy
            
            population[i] = clip_weights(population[i])
            new_fitness = compute_objectives(population[i], imf_predictions, true_values)
            fitness[i] = new_fitness
            archive = update_archive(archive, new_fitness, population[i])
    
    best_solution = min(archive, key=lambda x: x[0][0] + x[0][1])
    optimal_weights = clip_weights(best_solution[1])
    best_objectives = best_solution[0]
    
    print(f"  ✅ MOIGWODA完成: MAE={best_objectives[0]:.4f}, Std={best_objectives[1]:.4f}")
    print(f"  📊 Pareto前沿解数量: {len(archive)}")
    
    return optimal_weights, best_objectives[0], archive

# 2. NSGA-2多目标优化
def nsga2_optimize_weights(imf_predictions, true_values):
    """NSGA-2多目标优化"""
    print("  🔄 NSGA-2优化中...")
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    population = []
    for _ in range(pop_size):
        ind = np.random.uniform(0.3, 1.5, n_imfs)
        population.append(clip_weights(ind))
    
    archive = []
    
    for iteration in range(max_iter):
        fitness_values = [compute_objectives(ind, imf_predictions, true_values) for ind in population]
        
        offspring = []
        for ind in population:
            if np.random.rand() < 0.9:
                mutant = ind + np.random.normal(0, 0.1, n_imfs)
                mutant = clip_weights(mutant)
                offspring.append(mutant)
        
        combined = population + offspring
        combined_fitness = [compute_objectives(ind, imf_predictions, true_values) for ind in combined]
        
        sorted_indices = sorted(range(len(combined)), 
                              key=lambda i: combined_fitness[i][0] + combined_fitness[i][1])
        
        population = [combined[i].copy() for i in sorted_indices[:pop_size]]
        
        if iteration % 10 == 0:
            archive = [(combined_fitness[i], combined[i].copy()) for i in sorted_indices[:10]]
    
    fitness_values = [compute_objectives(ind, imf_predictions, true_values) for ind in population]
    best_idx = min(range(len(fitness_values)), 
                   key=lambda i: fitness_values[i][0] + fitness_values[i][1])
    optimal_weights = clip_weights(population[best_idx])
    best_objectives = fitness_values[best_idx]
    
    print(f"  ✅ NSGA-2完成: MAE={best_objectives[0]:.4f}, Std={best_objectives[1]:.4f}")
    
    return optimal_weights, best_objectives[0], archive

# 3. 多目标PSO优化
def mopso_optimize_weights(imf_predictions, true_values):
    """多目标PSO优化"""
    print("  🔄 多目标PSO优化中...")
    n_imfs = len(imf_predictions)
    pop_size = OPT_POP_SIZE
    max_iter = OPT_MAX_ITER
    
    particles = []
    velocities = []
    for _ in range(pop_size):
        particle = np.random.uniform(0.3, 1.5, n_imfs)
        particles.append(clip_weights(particle))
        velocities.append(np.random.uniform(-0.1, 0.1, n_imfs))
    
    particles = np.array(particles)
    velocities = np.array(velocities)
    
    pbest = particles.copy()
    pbest_fitness = np.array([compute_objectives(p, imf_predictions, true_values) for p in particles])
    
    gbest_idx = np.argmin([f[0] + f[1] for f in pbest_fitness])
    gbest = pbest[gbest_idx].copy()
    gbest_fitness = pbest_fitness[gbest_idx]
    
    archive = [(pbest_fitness[gbest_idx], gbest.copy())]
    
    w = 0.7
    c1 = 1.5
    c2 = 1.5
    
    for iteration in range(max_iter):
        for i in range(pop_size):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = (w * velocities[i] + 
                           c1 * r1 * (pbest[i] - particles[i]) +
                           c2 * r2 * (gbest - particles[i]))
            
            particles[i] = particles[i] + velocities[i]
            particles[i] = clip_weights(particles[i])
            
            fitness = compute_objectives(particles[i], imf_predictions, true_values)
            
            if fitness[0] + fitness[1] < pbest_fitness[i][0] + pbest_fitness[i][1]:
                pbest[i] = particles[i].copy()
                pbest_fitness[i] = fitness
                
                if fitness[0] + fitness[1] < gbest_fitness[0] + gbest_fitness[1]:
                    gbest = particles[i].copy()
                    gbest_fitness = fitness
                    archive.append((fitness, gbest.copy()))
    
    if len(archive) > 0:
        best_solution = min(archive, key=lambda x: x[0][0] + x[0][1])
        optimal_weights = clip_weights(best_solution[1])
        best_objectives = best_solution[0]
    else:
        optimal_weights = clip_weights(gbest)
        best_objectives = gbest_fitness
    
    print(f"  ✅ 多目标PSO完成: MAE={best_objectives[0]:.4f}, Std={best_objectives[1]:.4f}")
    print(f"  📊 存档解数量: {len(archive)}")
    
    return optimal_weights, best_objectives[0], archive

# ============================================================================
# 可视化函数
# ============================================================================

def plot_prediction_curves_only(results, test_dates, test_true, naive_mae, output_dir, stock_name, exp_num):
    """只生成预测曲线对比图"""
    fig = plt.figure(figsize=(20, 12))
    
    methods_to_plot = ['直接求和', 'MOIGWODA', 'NSGA-2', '多目标PSO']
    
    for idx, method in enumerate(methods_to_plot, 1):
        if method not in results:
            continue
            
        ax = plt.subplot(2, 2, idx)
        res = results[method]
        
        ax.plot(test_dates, test_true, label='实际价格', color='blue', 
                linewidth=2, marker='o', markersize=3, alpha=0.7)
        ax.plot(test_dates, res['pred'], label='预测价格', color='red', 
                linewidth=2, marker='s', markersize=3, alpha=0.7)
        
        improvement = (naive_mae - res['mae']) / naive_mae * 100
        
        ax.set_xlabel('日期', fontsize=12)
        ax.set_ylabel('价格 (USD)', fontsize=12)
        ax.set_title(f'{method}\nMAE={res["mae"]:.4f}, RMSE={res["rmse"]:.4f}, R²={res["r2"]:.4f}\n相对Naive改进: {improvement:+.2f}%',
                     fontsize=13, fontweight='bold')
        ax.legend(loc='best', fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    path = os.path.join(output_dir, f'{stock_name}_exp{exp_num}_prediction_curves.png')
    plt.savefig(path, dpi=300, bbox_inches='tight')
    print(f"  ✓ 已保存: {path}")
    plt.close()
    
    print(f"\n✅ 可视化完成！")

def main():
    print("="*80)
    print("实验9: CEEMDAN-ReliefF-MultiHeadAttLSTM 标准对比实验")
    print("="*80)
    print(f"使用设备: {DEVICE}")
    print(f"多头注意力：{NUM_HEADS}个头")
    print(f"权重约束: 0 < wi ≤ 1.5（CEEMDAN基线: wi=1.0）")
    print(f"优化算法: MOIGWODA、NSGA-2、多目标PSO")
    
    # 1. 加载数据
    print(f"\n{'='*80}")
    print("步骤1: 加载数据")
    print(f"{'='*80}")
    df = pd.read_excel(DATA_PATH, sheet_name='close')
    
    if STOCK_NAME not in df.columns:
        print(f"错误：找不到股票 {STOCK_NAME}")
        return
    
    data = pd.DataFrame({
        'date': pd.to_datetime(df.iloc[:, 0]),
        'close': df[STOCK_NAME].values
    })
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    data = data.sort_values('date').reset_index(drop=True)
    
    print(f"  股票代码: {STOCK_NAME}")
    print(f"  数据范围: {data['date'].min()} ~ {data['date'].max()}")
    print(f"  总样本数: {len(data)}")
    
    # 2. 分割数据
    train_size = int(len(data) * TRAIN_RATIO)
    train_data = data.iloc[:train_size]
    test_data = data.iloc[train_size:]
    
    print(f"\n{'='*80}")
    print("步骤2: 分割数据")
    print(f"{'='*80}")
    print(f"  训练集: {train_data['date'].min()} ~ {train_data['date'].max()} ({len(train_data)}样本)")
    print(f"  测试集: {test_data['date'].min()} ~ {test_data['date'].max()} ({len(test_data)}样本)")
    
    # 3. CEEMDAN分解
    print(f"\n{'='*80}")
    print("步骤3: CEEMDAN分解")
    print(f"{'='*80}")
    full_prices = data['close'].values
    ceemdan = CEEMDAN()
    imfs = ceemdan(full_prices)
    n_imfs = len(imfs)
    print(f"  ✓ 分解完成: {n_imfs}个IMF分量")
    
    # 4. 训练各个IMF
    print(f"\n{'='*80}")
    print("步骤4: ReliefF特征选择 + MultiHeadAttLSTM训练")
    print(f"{'='*80}")
    
    imf_test_predictions = []
    
    for i in range(n_imfs):
        print(f"\n--- IMF{i+1}/{n_imfs} ---")
        selected_lags = relieff_feature_selection(
            imfs[i], max_lag=MAX_LAG, n_features_to_select=N_FEATURES_TO_SELECT
        )
        
        train_pred, test_pred = train_single_imf_no_leakage(
            imfs[i], train_size, selected_lags, i
        )
        
        imf_test_predictions.append(test_pred)
    
    # 5. 对齐预测长度
    print(f"\n{'='*80}")
    print("步骤5: 对齐预测长度")
    print(f"{'='*80}")
    min_test_len = min(len(p) for p in imf_test_predictions)
    imf_test_predictions_aligned = [p[-min_test_len:] for p in imf_test_predictions]
    
    test_true = test_data['close'].values[-min_test_len:]
    test_dates = test_data['date'].values[-min_test_len:]
    
    print(f"  对齐后测试预测长度: {min_test_len}")
    print(f"\n各IMF预测统计:")
    for i, pred in enumerate(imf_test_predictions_aligned):
        print(f"  IMF{i+1}: 均值={np.mean(pred):.4f}, 标准差={np.std(pred):.4f}")
    
    # 6. 计算Naive Baseline
    naive_pred = test_true[:-1]
    naive_true = test_true[1:]
    naive_mae = mean_absolute_error(naive_true, naive_pred)
    naive_rmse = np.sqrt(mean_squared_error(naive_true, naive_pred))
    naive_r2 = r2_score(naive_true, naive_pred)
    
    print(f"\n{'='*80}")
    print("Naive Baseline性能")
    print(f"{'='*80}")
    print(f"  MAE={naive_mae:.4f}, RMSE={naive_rmse:.4f}, R²={naive_r2:.4f}")
    
    # 7. 集成实验
    results = {}
    
    # 方法1：直接求和（基线）
    print(f"\n{'='*80}")
    print("方法1: 直接求和（基线，CEEMDAN理论）")
    print(f"{'='*80}")
    equal_weights = np.ones(n_imfs)
    test_pred_equal = sum(w * p for w, p in zip(equal_weights, imf_test_predictions_aligned))
    mae_equal = mean_absolute_error(test_true, test_pred_equal)
    rmse_equal = np.sqrt(mean_squared_error(test_true, test_pred_equal))
    r2_equal = r2_score(test_true, test_pred_equal)
    print(f"  权重: {[f'{w:.4f}' for w in equal_weights]}（直接求和）")
    print(f"  MAE={mae_equal:.4f}, RMSE={rmse_equal:.4f}, R²={r2_equal:.4f}")
    results['直接求和'] = {
        'pred': test_pred_equal,
        'weights': equal_weights,
        'mae': mae_equal,
        'rmse': rmse_equal,
        'r2': r2_equal
    }
    
    # 方法2-4：多目标优化
    optimizers = {
        'MOIGWODA': moigwoda_optimize_weights,
        'NSGA-2': nsga2_optimize_weights,
        '多目标PSO': mopso_optimize_weights
    }
    
    for opt_name, opt_func in optimizers.items():
        print(f"\n{'='*80}")
        print(f"{opt_name} 多目标优化")
        print(f"{'='*80}")
        try:
            weights, mae_opt, archive = opt_func(imf_test_predictions_aligned, test_true)
            
            print(f"  ✅ 优化权重: {[f'{w:.4f}' for w in weights]}")
            print(f"  ✅ 权重和: {np.sum(weights):.4f} (基线=8.0)")
            print(f"  ✅ 权重范围: [{np.min(weights):.4f}, {np.max(weights):.4f}]")
            
            test_pred = sum(w * p for w, p in zip(weights, imf_test_predictions_aligned))
            rmse_opt = np.sqrt(mean_squared_error(test_true, test_pred))
            r2_opt = r2_score(test_true, test_pred)
            
            print(f"  📊 性能: MAE={mae_opt:.4f}, RMSE={rmse_opt:.4f}, R²={r2_opt:.4f}")
            
            results[opt_name] = {
                'pred': test_pred,
                'weights': weights,
                'mae': mae_opt,
                'rmse': rmse_opt,
                'r2': r2_opt,
                'archive': archive
            }
        except Exception as e:
            print(f"  ✗ {opt_name} 失败: {e}")
            import traceback
            traceback.print_exc()
    
    # 8. 结果对比
    print(f"\n{'='*80}")
    print("实验结果对比")
    print(f"{'='*80}")
    
    print(f"\n{'方法':<20} {'MAE':<12} {'RMSE':<12} {'R²':<12} {'vs Naive':<15} {'vs直接求和':<15}")
    print("-" * 90)
    print(f"{'Naive (t=t-1)':<20} {naive_mae:<12.4f} {naive_rmse:<12.4f} {naive_r2:<12.4f} {'基准':<15} {'-':<15}")
    print("-" * 90)
    
    for method_name, res in results.items():
        improvement_naive = (naive_mae - res['mae']) / naive_mae * 100
        improvement_equal = (mae_equal - res['mae']) / mae_equal * 100
        
        imp_str_naive = f"+{improvement_naive:.1f}%" if improvement_naive > 0 else f"{improvement_naive:.1f}%"
        imp_str_equal = f"+{improvement_equal:.1f}%" if improvement_equal > 0 else f"{improvement_equal:.1f}%"
        
        print(f"{method_name:<20} {res['mae']:<12.4f} {res['rmse']:<12.4f} {res['r2']:<12.4f} {imp_str_naive:<15} {imp_str_equal:<15}")
    
    best_method = min(results.keys(), key=lambda k: results[k]['mae'])
    print(f"\n🏆 最优方法: {best_method} (MAE={results[best_method]['mae']:.4f})")
    
    # 9. 可视化
    print(f"\n{'='*80}")
    print("步骤6: 生成可视化")
    print(f"{'='*80}")
    plot_prediction_curves_only(results, test_dates, test_true, naive_mae, OUTPUT_DIR, STOCK_NAME, 9)
    
    # 10. 保存结果
    print(f"\n{'='*80}")
    print("步骤7: 保存结果")
    print(f"{'='*80}")
    
    # CSV结果
    results_df = pd.DataFrame({
        'date': test_dates,
        'actual': test_true
    })
    
    for method_name, res in results.items():
        col_name = f'pred_{method_name.lower().replace(" ", "_").replace("-", "_")}'
        results_df[col_name] = res['pred']
    
    results_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp9_results.csv')
    results_df.to_csv(results_path, index=False)
    print(f"  ✓ 预测结果已保存: {results_path}")
    
    # 权重结果
    weights_data = []
    for method_name, res in results.items():
        if 'weights' in res:
            row = {'method': method_name}
            for i, w in enumerate(res['weights']):
                row[f'IMF{i+1}'] = w
            row['sum'] = np.sum(res['weights'])
            weights_data.append(row)
    
    weights_df = pd.DataFrame(weights_data)
    weights_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp9_weights.csv')
    weights_df.to_csv(weights_path, index=False)
    print(f"  ✓ 权重结果已保存: {weights_path}")
    
    # 性能汇总
    summary_data = []
    summary_data.append({
        'method': 'Naive',
        'MAE': naive_mae,
        'RMSE': naive_rmse,
        'R2': naive_r2,
        'vs_Naive': '0.0%',
        'vs_DirectSum': '-'
    })
    
    for method_name, res in results.items():
        improvement_naive = (naive_mae - res['mae']) / naive_mae * 100
        improvement_equal = (mae_equal - res['mae']) / mae_equal * 100
        
        summary_data.append({
            'method': method_name,
            'MAE': res['mae'],
            'RMSE': res['rmse'],
            'R2': res['r2'],
            'vs_Naive': f"{improvement_naive:+.2f}%",
            'vs_DirectSum': f"{improvement_equal:+.2f}%"
        })
    
    summary_df = pd.DataFrame(summary_data)
    summary_path = os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_exp9_summary.csv')
    summary_df.to_csv(summary_path, index=False)
    print(f"  ✓ 性能汇总已保存: {summary_path}")
    
    print(f"\n{'='*80}")
    print("✅ 实验9完成！")
    print(f"{'='*80}")
    print(f"📁 所有结果已保存至: {OUTPUT_DIR}")
    print(f"🏆 最优方法: {best_method}")
    print(f"📊 MAE改进: {(naive_mae - results[best_method]['mae']) / naive_mae * 100:+.2f}% (vs Naive)")
    print(f"\n💡 多头注意力效果分析:")
    print(f"  对比exp4（标准AttLSTM）的结果，评估多头注意力的改进效果")

if __name__ == '__main__':
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 实验失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
