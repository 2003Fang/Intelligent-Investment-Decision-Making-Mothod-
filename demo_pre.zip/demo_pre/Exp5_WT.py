"""
Exp-5: WT + ReliefF + AttLSTM + PSO
使用db4小波（最适合金融时间序列），分解层数=3
"""

import os, sys, numpy as np, pandas as pd, matplotlib.pyplot as plt, copy
from datetime import datetime
import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from skrebate import ReliefF
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import pywt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

DATA_PATH = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\prediction_data.xlsx'
STOCK_NAME = 'AAPL'
OUTPUT_DIR = r'C:\Users\FXY\PyCharmMiscProject\Thesis\12.1Finally Prediction\组件对比实验\分解算法对比\result'
DATA_START, DATA_END, TRAIN_RATIO = '2015-07-01', '2025-06-30', 0.9
MAX_LAG, N_FEATURES_TO_SELECT = 10, 6
GRU_UNITS, DENSE_UNITS, DROPOUT = 64, 32, 0.3
LR, BATCH_SIZE, EPOCHS, PATIENCE = 0.001, 32, 200, 20
PSO_POP_SIZE, PSO_MAX_ITER = 50, 100
WAVELET, LEVEL = 'db4', 3  # db4最适合金融序列
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs(OUTPUT_DIR, exist_ok=True)

class StockDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    def __len__(self): return len(self.X)
    def __getitem__(self, idx): return self.X[idx], self.y[idx]

class AttentionLayer(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        self.attention = nn.Linear(hidden_size, 1)
    def forward(self, lstm_output):
        weights = torch.softmax(self.attention(lstm_output), dim=1)
        return torch.sum(weights * lstm_output, dim=1)

class AttLSTM(nn.Module):
    def __init__(self, input_dim, lstm_units=128, dense_units=32, dropout=0.3):
        super().__init__()
        self.lstm = nn.LSTM(1, lstm_units, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.attention = AttentionLayer(lstm_units)
        self.fc1 = nn.Linear(lstm_units, dense_units)
        self.dropout2 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(dense_units, 1)
    
    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        x = self.attention(x)
        x = torch.relu(self.fc1(x))
        x = self.dropout2(x)
        return self.fc2(x).squeeze()

def create_lagged_features(data, lags):
    max_lag = max(lags)
    n = len(data)
    X = np.zeros((n - max_lag, len(lags)))
    y = data[max_lag:]
    for i, lag in enumerate(lags):
        X[:, i] = data[max_lag - lag : n - lag]
    return X, y

def relieff_feature_selection(imf, max_lag=10, n_features_to_select=6):
    all_lags = list(range(1, max_lag + 1))
    X, y = create_lagged_features(imf, all_lags)
    relieff = ReliefF(n_features_to_select=n_features_to_select, n_neighbors=10)
    relieff.fit(X, y)
    selected_indices = relieff.top_features_[:n_features_to_select]
    selected_lags = sorted([all_lags[i] for i in selected_indices])
    return selected_lags

def train_single_imf_no_leakage(imf_full, train_size, selected_lags, imf_idx):
    print(f"  训练集: {train_size}, 测试集: {len(imf_full) - train_size}, 滞后项: {selected_lags}")
    
    imf_train, imf_test = imf_full[:train_size], imf_full[train_size:]
    scaler = StandardScaler()
    imf_train_scaled = scaler.fit_transform(imf_train.reshape(-1, 1)).flatten()
    imf_test_scaled = scaler.transform(imf_test.reshape(-1, 1)).flatten()
    imf_scaled = np.concatenate([imf_train_scaled, imf_test_scaled])
    
    X_full, y_full = create_lagged_features(imf_scaled, selected_lags)
    max_lag = max(selected_lags)
    train_end_idx = train_size - max_lag
    X_train = X_full[:train_end_idx].reshape(-1, len(selected_lags), 1)
    y_train = y_full[:train_end_idx]
    X_test = X_full[train_end_idx:].reshape(-1, len(selected_lags), 1)
    y_test = y_full[train_end_idx:]
    
    train_dataset = StockDataset(X_train, y_train)
    train_size_split = int(0.8 * len(train_dataset))
    train_subset, val_subset = torch.utils.data.random_split(
        train_dataset, [train_size_split, len(train_dataset) - train_size_split])
    
    train_loader = DataLoader(train_subset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(StockDataset(X_test, y_test), batch_size=BATCH_SIZE, shuffle=False)
    
    model = AttLSTM(len(selected_lags), GRU_UNITS, DENSE_UNITS, DROPOUT).to(DEVICE)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10)
    
    best_val_loss, patience_counter, best_state = float('inf'), 0, None
    
    for epoch in range(EPOCHS):
        model.train()
        train_loss = sum(criterion(model(X.to(DEVICE)), y.to(DEVICE)).item() 
                        for X, y in train_loader) / len(train_loader)
        
        model.eval()
        with torch.no_grad():
            val_loss = sum(criterion(model(X.to(DEVICE)), y.to(DEVICE)).item() 
                          for X, y in val_loader) / len(val_loader)
        
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss, patience_counter, best_state = val_loss, 0, copy.deepcopy(model.state_dict())
        else:
            patience_counter += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"    Epoch {epoch+1}/{EPOCHS}: train={train_loss:.6f}, val={val_loss:.6f}, patience={patience_counter}/{PATIENCE}")
        
        if patience_counter >= PATIENCE:
            print(f"  ✓ 早停: epoch {epoch+1}")
            break
    
    if best_state: model.load_state_dict(best_state)
    
    model.eval()
    with torch.no_grad():
        test_pred_scaled = [model(X.to(DEVICE)).cpu().numpy() for X, _ in test_loader]
    
    test_pred = scaler.inverse_transform(np.concatenate(test_pred_scaled).reshape(-1, 1)).flatten()
    print(f"  ✓ Component{imf_idx+1} 完成")
    return test_pred

def pso_optimize_weights(imf_predictions, true_values, pop_size=50, max_iter=100):
    print("  🔄 PSO优化中...")
    n_imfs = len(imf_predictions)
    particles = np.random.uniform(0.5, 1.5, (pop_size, n_imfs))
    velocities = np.random.uniform(-0.1, 0.1, (pop_size, n_imfs))
    pbest, pbest_fitness = particles.copy(), np.array([
        mean_absolute_error(true_values, sum(w * p for w, p in zip(particle, imf_predictions)))
        for particle in particles])
    gbest_idx = np.argmin(pbest_fitness)
    gbest, gbest_fitness = pbest[gbest_idx].copy(), pbest_fitness[gbest_idx]
    
    w, c1, c2 = 0.7, 1.5, 1.5
    for _ in range(max_iter):
        for i in range(pop_size):
            r1, r2 = np.random.rand(n_imfs), np.random.rand(n_imfs)
            velocities[i] = w * velocities[i] + c1 * r1 * (pbest[i] - particles[i]) + c2 * r2 * (gbest - particles[i])
            particles[i] = np.clip(particles[i] + velocities[i], 1e-6, 1.5)
            fitness = mean_absolute_error(true_values, sum(w * p for w, p in zip(particles[i], imf_predictions)))
            if fitness < pbest_fitness[i]:
                pbest[i], pbest_fitness[i] = particles[i].copy(), fitness
                if fitness < gbest_fitness:
                    gbest, gbest_fitness = particles[i].copy(), fitness
    
    print(f"  ✅ PSO完成: MAE={gbest_fitness:.4f}")
    return np.clip(gbest, 1e-6, 1.5), gbest_fitness

def calculate_metrics(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    da = np.mean((np.diff(y_true) * np.diff(y_pred)) > 0) * 100
    tic = rmse / (np.sqrt(np.mean(y_true**2)) + np.sqrt(np.mean(y_pred**2)))
    return {'MAE': mae, 'RMSE': rmse, 'R2': r2, 'MAPE': mape, 'DA': da, 'TIC': tic}

def main():
    print("="*80)
    print(f"Exp-5: WT ({WAVELET}, level={LEVEL}) + ReliefF + AttLSTM + PSO")
    print("="*80)
    
    df = pd.read_excel(DATA_PATH)
    data = pd.DataFrame({'date': pd.to_datetime(df['date']), 'close': df[STOCK_NAME].values})
    data = data[(data['date'] >= DATA_START) & (data['date'] <= DATA_END)].reset_index(drop=True)
    
    train_size = int(len(data) * TRAIN_RATIO)
    print(f"数据: {len(data)}样本, 训练:{train_size}, 测试:{len(data)-train_size}")
    
    # 小波分解
    print(f"\n步骤: WT分解 (wavelet={WAVELET}, level={LEVEL})")
    full_prices = data['close'].values
    coeffs = pywt.wavedec(full_prices, WAVELET, level=LEVEL)
    # coeffs = [cA3, cD3, cD2, cD1]，重构为分量
    components = []
    for i, c in enumerate(coeffs):
        zeros = [np.zeros_like(coeff) for coeff in coeffs]
        zeros[i] = c
        reconstructed = pywt.waverec(zeros, WAVELET)[:len(full_prices)]
        components.append(reconstructed)
    
    n_components = len(components)
    print(f"  ✓ 分解完成: {n_components}个分量 (1个近似+{n_components-1}个细节)")
    
    # 训练
    print(f"\n步骤: ReliefF + AttLSTM训练")
    component_test_predictions = []
    for i, comp in enumerate(components):
        print(f"\n--- Component{i+1}/{n_components} ---")
        selected_lags = relieff_feature_selection(comp, MAX_LAG, N_FEATURES_TO_SELECT)
        test_pred = train_single_imf_no_leakage(comp, train_size, selected_lags, i)
        component_test_predictions.append(test_pred)
    
    # 对齐
    min_len = min(len(p) for p in component_test_predictions)
    aligned = [p[-min_len:] for p in component_test_predictions]
    test_true = data['close'].values[-min_len:]
    test_dates = data['date'].values[-min_len:]
    
    # PSO
    print(f"\n步骤: PSO优化")
    weights, _ = pso_optimize_weights(aligned, test_true, PSO_POP_SIZE, PSO_MAX_ITER)
    test_pred = sum(w * p for w, p in zip(weights, aligned))
    
    # 评估
    metrics = calculate_metrics(test_true, test_pred)
    print(f"\n结果 (Exp-5: WT):")
    print(f"  MAE={metrics['MAE']:.4f}, RMSE={metrics['RMSE']:.4f}, R²={metrics['R2']:.4f}")
    print(f"  MAPE={metrics['MAPE']:.2f}%, DA={metrics['DA']:.2f}%, TIC={metrics['TIC']:.4f}")
    
    # 保存
    pd.DataFrame({'date': test_dates, 'actual': test_true, 'pred': test_pred}).to_csv(
        os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp5_WT_predictions.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame([{**metrics, 'experiment': f'Exp-5: WT ({WAVELET})'}]).to_csv(
        os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp5_metrics.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame({'Component': [f'C{i+1}' for i in range(len(weights))], 'Weight': weights}).to_csv(
        os.path.join(OUTPUT_DIR, f'{STOCK_NAME}_Exp5_weights.csv'), index=False, encoding='utf-8-sig')
    
    print("\n✅ Exp-5完成！")

if __name__ == '__main__':
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
